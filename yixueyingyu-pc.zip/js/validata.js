define(['jquery','md5'],function ($) {
    return {
        getQueryString:function (name) {
            var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
            var r = window.location.search.substr(1).match(reg);
            if (r != null) return unescape(r[2]); return null;
        },
        isEqual:function (str1,str2) {
            return str1 === str2;
        },
        isApi:function () {
            return api = 'http://api.store.zhongmeiyixue.com';
            // return api = 'http://store.jiudingfanyi.test';
        },
        isUid:function () {
            return uid = localStorage.getItem('uid');
            // return uid = '4688641529922092';
        },
        uinfo:function (uname,uavatar,umobile) {
            $('header .head_right .head').find('img').attr('src',uavatar);
            $('header .head_right p').text(uname);
            $('.phone .delivery_bot .delivery_list p').text(umobile);
        },
        isOpenid:function () {
            return openid = localStorage.getItem('openid');
            // return openid = 'oy9eZ0e4D5gfdBKNz7WWhQuTi0ds';
        },
        signCont:function() {
            var timestamp = Date.parse(new Date()) / 1000;
            var sign = 'wx_first' + timestamp + 'ezYQAe5UEi5UMHtY';
            sign = $.md5(sign);
            var signCont = {
                key: 'wx_first',
                sign: sign,
                timestamp: timestamp
            };
            return signCont
        }
    }
});