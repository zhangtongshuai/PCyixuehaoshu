requirejs(['common'],function(c){
    requirejs(['jquery','validata','style'],function ($,validata,style) {
        console.log(validata.isEqual(1,2))
        var api = validata.isApi();
        var uid = validata.isUid();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        var uname = localStorage.getItem('uname');
        var uavatar = localStorage.getItem('uavatar');
        var umobile = localStorage.getItem('umobile');
        validata.uinfo(uname,uavatar,umobile);
        layui.use(['upload'], function(){
            var layer = layui.layer
                ,upload = layui.upload;
            //普通图片上
            var uploadInst1 = upload.render({
                elem: '#portrait1'
                ,url: api+'/api/img?type=avatar&module=market'
                ,field: 'image'
                ,before: function(obj){
                    //预读本地文件示例，不支持ie8
                    obj.preview(function(index, file, result){
                        $('#portrait').attr('src', result); //图片链接（base64）
                    });
                }
                ,done: function(res){
                    if(res.code == 200){
                       //上传成功
                        var portraitimg = res.result.path;
                        $('#portrait1').attr('portraitimg', portraitimg);
                        return layer.msg('上传成功');
                    }else{
                       //如果上传失败
                        return layer.msg('上传失败');
                    }
                }
                ,error: function(){
                    //演示失败状态，并实现重传
                    var demoText = $('#portraitText');
                    demoText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-xs demo-reload">重试</a>');
                    demoText.find('.demo-reload').on('click', function(){
                        uploadInst1.upload();
                    });
                }
            });
            var uploadInst = upload.render({
                elem: '#qrcode1'
                ,url: api+'/api/img?type=qrcode&module=market'
                ,field: 'image'
                ,before: function(obj){
                    //预读本地文件示例，不支持ie8
                    obj.preview(function(index, file, result){
                        $('#qrcode').attr('src', result); //图片链接（base64）
                    });
                }
                ,done: function(res){
                    if(res.code == 200){
                        //上传成功
                        var qrcodeimg = res.result.path;
                        $('#qrcode1').attr('qrcodeimg', qrcodeimg);
                        return layer.msg('上传成功');
                    }else{
                        //如果上传失败
                        return layer.msg('上传失败');
                    }
                }
                ,error: function(){
                    //演示失败状态，并实现重传
                    var demoText = $('#qrcodeText2');
                    demoText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-xs demo-reload">重试</a>');
                    demoText.find('.demo-reload').on('click', function(){
                        uploadInst.upload();
                    });
                }
            });

            $.ajax({
                type: 'post',
                url: api+'/api/index',
                data:{
                    module:'member',
                    method:'user.show',
                    request_mode:'post',
                    key:key,
                    sign:sign,
                    timestamp:timestamp,
                    uid:uid
                },
                dataType: 'json',
                success: function (a) {
                    console.log(a);
                    if(a.status =='success') {
                        $('.shopSetting .shopID').val(a.result.uid);
                        $('.shopSetting #portrait').attr('src',a.result.avatar);
                        $('.shopSetting #portrait1').attr('portraitimg',a.result.avatar);
                        $('.shopSetting .shopName').val(a.result.name);
                        $('.shopSetting .adress').val(a.result.address);
                        $('.shopSetting .brief').val(a.result.brief);
                        $('.shopSetting .mobile').val(a.result.mobile);
                        $('.shopSetting #qrcode').attr('src',a.result.qrcode);
                        $('.shopSetting #qrcode1').attr('qrcodeimg',a.result.qrcode);
                        var province = a.result.province;
                        var city = a.result.city;
                        function select1() {
                            var options = '';
                            $.ajax({
                                type: "post",
                                url: api+'/api/index',
                                data:{
                                    module:'member',
                                    method:'address.get_province',
                                    request_mode:'post',
                                    key:key,
                                    sign:sign,
                                    timestamp:timestamp
                                },
                                dataType: 'json',
                                success: function (b) {
                                    for(var i=0; i<b.result.length; i++){
                                        if(b.result[i].id ==province){
                                            options += '<option selected value="'+b.result[i].id+'">'+b.result[i].district_name+'</option>'
                                        }else{
                                            options += '<option value="'+b.result[i].id+'">'+b.result[i].district_name+'</option>'
                                        }
                                    }
                                    $('.shopSetting .province').append(options);
                                    select2();
                                }
                            })
                        }
                        function select2() {
                            var citys = '';
                            $(".shopSetting .city").html('');
                            var options=$(".shopSetting .province option:selected");
                            var pid = options.attr("value");
                            $.ajax({
                                async:false,
                                type: "post",
                                url: api+'/api/index?pid='+pid,
                                data:{
                                    module:'member',
                                    method:'address.get_city',
                                    request_mode:'post',
                                    key:key,
                                    sign:sign,
                                    timestamp:timestamp
                                },
                                success: function (c) {
                                    for(var j=0;j<c.result.length; j++){
                                        if(c.result[j].id ==city){
                                            citys += '<option selected value="'+c.result[j].id+'">'+c.result[j].district_name+'</option>'
                                        }else{
                                            citys += '<option value="'+c.result[j].id+'">'+c.result[j].district_name+'</option>'
                                        }
                                    }
                                    $('.shopSetting .city').html(citys);
                                }
                            })
                        }
                        $(function () {
                            select1();
                            $('.province').bind("change", select2);
                        });
                    }else{
                        layer.alert(a.msg)
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    // alert(XMLHttpRequest.status);
                    // alert(XMLHttpRequest.readyState);
                    // alert(textStatus);
                }
            });
            $('.cancel_btn').on('click',function () {
                window.location.reload();
            });
            $('.hold_btn').on('click',function () {
                var avatar = $('#portrait1').attr('portraitimg');
                var name = $('.shopName').val();
                var province_name= $(".shopSetting .province option:selected").text();
                var province =  $(".shopSetting .province option:selected").attr("value");
                var city_name = $(".shopSetting .city option:selected").text();
                var city = $(".shopSetting .city option:selected").attr("value");
                var address = $('.shopSetting .adress').val();
                var brief = $('.shopSetting .brief').val();
                var mobile = $('.shopSetting .mobile').val();
                var qrcode=$('#qrcode1').attr('qrcodeimg');
                if(avatar == ''){
                    layer.alert('请上传头像');
                    return false;
                }else if(name == ''){
                    layer.alert('请填写名称');
                    return false;
                }else if(address == ''){
                    layer.alert('请填写详细地址');
                    return false;
                }else if(mobile == ''){
                    layer.alert('请填写联系方式');
                    return false;
                }else if(!(/^1[34578]\d{9}$/.test(mobile))){
                    layer.alert('联系方式请输入正确的手机号');
                    return false;
                }
                $.ajax({
                    async:false,
                    type: "post",
                    url: api+'/api/index',
                    data:{
                        uid:uid,
                        avatar:avatar,
                        name:name,
                        province_name:province_name,
                        province:province,
                        city_name:city_name,
                        city:city,
                        address:address,
                        brief:brief,
                        mobile:mobile,
                        qrcode:qrcode,
                        module:'member',
                        method:'user.update',
                        request_mode:'post',
                        key:key,
                        sign:sign,
                        timestamp:timestamp
                    },
                    success: function (d) {
                        console.log(d);
                        if(d.status =='success'){
                            localStorage.setItem('uname',name);
                            localStorage.setItem('uavatar',avatar);
                            $('header .head_right .head').find('img').attr('src',avatar);
                            $('header .head_right p').text(name);
                            layer.msg('保存成功');
                        }else{
                            layer.alert(d.msg)
                        }
                    }
                })
            });
            $('.phone .delivery_list3 button').eq(1).on('click',function () {
                var p_this=$(this);
                var newphone =  p_this.parents('.delivery_bot').find('.delivery_list2').find('input').val();
                var oldphone = p_this.parents('.delivery_bot').find('.delivery_list').eq(0).find('p').text();
                if(!(/^1(3|4|5|7|8)\d{9}$/.test(newphone))){
                    layer.alert('请输入正确的手机号');
                    return false;
                }else if(newphone == oldphone){
                    layer.alert('手机号未做更改');
                    return false;
                }
                $.ajax({
                    url: api + '/api/index',
                    type:'post',
                    data:{
                        id:'1',
                        code:'123',
                        key:key,
                        method:'message.updateMobile',
                        module:'system',
                        mobile:newphone,
                        request_mode:'post',
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType:'json',
                    success:function(a){
                        if(a.status =='success') {
                            $('.phone').hide();
                            localStorage.setItem('umobile',newphone);
                            p_this.parents('.delivery_bot').find('.delivery_list').eq(0).find('p').text(newphone);
                            p_this.parents('.delivery_bot').find('.delivery_list2').find('input').val('');
                        }else{
                            layer.alert(a.msg)
                        }
                    }
                });
            });
            $('.password2 .delivery_list3 button').eq(1).on('click',function () {
                var ps_this=$(this);
                var password1 = ps_this.parents('.delivery_bot').find('.delivery_list2').eq(0).find('input').val();
                var password2 =  ps_this.parents('.delivery_bot').find('.delivery_list2').eq(1).find('input').val();
                if(password1 == ''){
                    layer.alert('请输入新密码');
                    return false;
                }else if(password1.length <6){
                    layer.alert('请输入6位以上密码');
                    return false;
                }else if(password2 == ''){
                    layer.alert('请输入确认密码');
                    return false;
                }else if(password1 != password2){
                    layer.alert('确认密码和新密码不一致');
                    return false;
                }
                $.ajax({
                    url: api + '/api/index',
                    type:'post',
                    data:{
                        key:key,
                        method:'user.edit_password',
                        module:'member',
                        password:password2,
                        request_mode:'post',
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType:'json',
                    success:function(a){
                        if(a.status =='success') {
                            $('.password2').hide();
                            window.location.href='index.html';
                        }else{
                            layer.alert(a.msg)
                        }
                    }
                });
            });
        });
    })
});
