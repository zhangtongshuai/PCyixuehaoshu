requirejs(['common'],function(c){
    requirejs(['jquery','validata','style'],function ($,validata,style) {
        console.log(validata.isEqual(1,2))
        var api = validata.isApi();
        var uid = validata.isUid();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        var uname = localStorage.getItem('uname');
        var uavatar = localStorage.getItem('uavatar');
        var umobile = localStorage.getItem('umobile');
        var g_id = validata.getQueryString('gid');
        var s_id = validata.getQueryString('sid');
        validata.uinfo(uname,uavatar,umobile);
        layui.use(['laydate','upload'], function(){
            var layer = layui.layer
                ,laydate = layui.laydate
                ,upload = layui.upload;

            //日期
            laydate.render({
                elem: '#publish_date',
                type: 'datetime'
            });

            //普通图片上传
            var uploadInst1 = upload.render({
                elem: '#book_cover1'
                ,url: api+'/api/img?type=cover&module=market'
                ,size: 300
                ,field: 'image'
                ,before: function(obj){
                    //预读本地文件示例，不支持ie8
                    obj.preview(function(index, file, result){
                        $('#book_cover').attr('src', result); //图片链接（base64）
                    });
                }
                ,done: function(res){
                    if(res.code == 200){
                        //上传成功
                        var book_coverimg = res.result.path;
                        $('#book_cover1').attr('book_coverimg', book_coverimg);
                        return layer.msg('上传成功');
                    }else{
                        //如果上传失败
                        return layer.msg('上传失败');
                    }
                }
                ,error: function(){
                    //演示失败状态，并实现重传
                    var demoText = $('#book_coverText');
                    demoText.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-xs demo-reload">重试</a>');
                    demoText.find('.demo-reload').on('click', function(){
                        uploadInst1.upload();
                    });
                }
            });
            var E = window.wangEditor
            var editor = new E('#editor_id')
            // 自定义菜单配置
            editor.customConfig.menus = [
                'head',  // 标题
                'bold',  // 粗体
                'fontSize',  // 字号
                'fontName',  // 字体
                'italic',  // 斜体
                'underline',  // 下划线
                'strikeThrough',  // 删除线
                'foreColor',  // 文字颜色
                'backColor',  // 背景颜色
                'link',  // 插入链接
                'justify',  // 对齐方式
                'quote',  // 引用
                'image',  // 插入图片
                'table'  // 表格
            ]
            // 或者 var editor = new E( document.getElementById('editor') )
            editor.customConfig.uploadImgServer = api+'/api/img?type=description&module=market';
            editor.customConfig.uploadImgMaxSize = 300 * 1024;
            editor.customConfig.uploadImgMaxLength = 1;
            editor.customConfig.uploadFileName = 'image';
            editor.customConfig.uploadImgHeaders = {
                'Accept': 'text/x-json'
            }
            editor.customConfig.uploadImgHooks = {
                before: function (xhr, editor, files) {

                    // 图片上传之前触发
                    // xhr 是 XMLHttpRequst 对象，editor 是编辑器对象，files 是选择的图片文件

                    // 如果返回的结果是 {prevent: true, msg: 'xxxx'} 则表示用户放弃上传
                    // return {
                    //     prevent: true,
                    //     msg: '放弃上传'
                    // }
                },
                success: function (xhr, editor, result) {
                    // console.log(xhr)
                    // console.log(editor)
                    // console.log(result)
                    if(result.code!=200){
                        layer.alert('上传失败')
                        // var imgurl = result.result.path;
                        // var imginfo =  '<img src="'+imgurl+'">';
                        // editor.txt.html(imginfo);
                    }
                    // 图片上传并返回结果，图片插入成功之后触发
                    // xhr 是 XMLHttpRequst 对象，editor 是编辑器对象，result 是服务器端返回的结果
                },
                fail: function (xhr, editor, result) {
                    // 图片上传并返回结果，但图片插入错误时触发
                    // xhr 是 XMLHttpRequst 对象，editor 是编辑器对象，result 是服务器端返回的结果
                },
                error: function (xhr, editor) {
                    layer.alert('上传出错，请刷新页面重新上传')
                    // 图片上传出错时触发
                    // xhr 是 XMLHttpRequst 对象，editor 是编辑器对象
                },
                timeout: function (xhr, editor) {
                    layer.alert('上传超时，请刷新页面重新上传')
                    // 图片上传超时时触发
                    // xhr 是 XMLHttpRequst 对象，editor 是编辑器对象
                },

                // 如果服务器端返回的不是 {errno:0, data: [...]} 这种格式，可使用该配置
                // （但是，服务器端返回的必须是一个 JSON 格式字符串！！！否则会报错）
                customInsert: function (insertImg, result, editor) {
                    // 图片上传并返回结果，自定义插入图片的事件（而不是编辑器自动插入图片！！！）
                    // insertImg 是插入图片的函数，editor 是编辑器对象，result 是服务器端返回的结果

                    // 举例：假如上传图片成功后，服务器端返回的是 {url:'....'} 这种格式，即可这样插入图片：
                    insertImg(result.result.path)

                    // result 必须是一个 JSON 格式字符串！！！否则报错
                }
            }
            editor.create();
            $('#editor_id').attr('style','height:auto;');
            $('#editor_id').attr('style','width:506px;');
            if(g_id){
                $.ajax({
                    type: 'get',
                    url: api+'/api/index',
                    data:{
                        module:'market',
                        method:'market.'+g_id,
                        request_mode:'get',
                        key:key,
                        sign:sign,
                        timestamp:timestamp
                    },
                    dataType: 'json',
                    success: function (b) {
                        $('.goodscode').val(b.result.code);
                        $('.goodsname').val(b.result.name);
                        $('.prime_price').val(b.result.original_price);
                        $('.author').val(b.result.author);
                        $('.pages').val(b.result.pages);
                        $('.press').val(b.result.manufactor);
                        $('#publish_date').val(b.result.produce_date);
                        if(b.result.market_many_image !=''){
                            $('#book_cover1').attr('book_coverimg',b.result.market_many_image[0].image);
                            $('#book_cover').attr('src',b.result.market_many_image[0].image);
                        }
                        $('.spot_price').val(b.result.price);
                        $('.stock').val(b.result.number);
                        editor.txt.html(b.result.brief);
                        $('.referee_deduct').val(b.result.referral_fee);
                        $('.remarks').val(b.result.remark);
                        sessionStorage.setItem('edit_status',b.result.status);
                    }
                });
            }
            if(!g_id && !s_id){
                $(".goodscode").blur(function(){
                    var goodscode = $('.goodscode').val();
                    goodscode = goodscode.replace(/\s+/g,"");
                    if(goodscode!=''){
                        if(goodscode.length !=13){
                            layer.alert('请输入13位ISBN/物品码');
                            return false;
                        }
                        $.ajax({
                            type: 'get',
                            url: api+'/api/index',
                            data:{
                                module:'market',
                                method:'market.pre_query',
                                request_mode:'get',
                                key:key,
                                sign:sign,
                                timestamp:timestamp,
                                isbn:goodscode,
                                uid:uid
                            },
                            dataType: 'json',
                            success: function (a) {
                                console.log(a);
                                if (a.code == 201) {
                                    var ggid = a.result.id;
                                    layer.confirm('店铺已拥有该商品,是否查看', {
                                        btn: ['查看', '否'] //可以无限个按钮
                                    }, function(index, layero){
                                        window.location.href='entitySale.html?gid='+ggid;
                                    }, function(index){
                                        //按钮【按钮二】的回调
                                    });
                                }else if(a.code == 200){
                                    $('.goodscode').val(a.result.code);
                                    $('.goodsname').val(a.result.name);
                                    $('.prime_price').val(a.result.price);
                                    $('.author').val(a.result.author);
                                    $('.pages').val(a.result.pages);
                                    $('.press').val(a.result.manufactor);
                                    $('#publish_date').val(a.result.produce_date);
                                    if(a.result.image !=''){
                                        $('#book_cover1').attr('book_coverimg',a.result.image);
                                        $('#book_cover').attr('src',a.result.image);
                                    }
                                    editor.txt.html(a.result.brief);
                                    sessionStorage.setItem('edit_status','1');
                                }else if(a.code == 404){
                                    sessionStorage.setItem('edit_status','2');
                                }
                            }
                        });
                    }
                });
            }
            $('.entity_release').on('click',function () {
                var goodscode = $('.goodscode').val();
                goodscode = goodscode.replace(/\s+/g,"");
                var goodsname = $('.goodsname').val();
                var prime_price = $('.prime_price').val();
                var author = $('.author').val();
                var pages = $('.pages').val();
                var press = $('.press').val();
                var publish_date = $('#publish_date').val();
                var book_coverimg = $('#book_cover1').attr('book_coverimg');
                var spot_price = $('.spot_price').val();
                var stock = $('.stock').val();
                var describe = editor.txt.html();
                var referee_deduct = $('.referee_deduct').val();
                var remarks = $('.remarks').val();
                if(goodsname == ''){
                    layer.msg('商品名不能为空');
                    return false;
                }else if(prime_price == ''){
                    layer.msg('原价不能为空');
                    return false;
                }else if(publish_date == ''){
                    layer.msg('出版日期不能为空');
                    return false;
                }else if(spot_price == ''){
                    layer.msg('现货价格不能为空');
                    return false;
                }else if(stock == ''){
                    layer.msg('库存不能为空');
                    return false;
                }else if(referee_deduct == ''){
                    layer.msg('推荐人提成不能为空');
                    return false;
                }else if(referee_deduct < 1){
                    layer.msg('推荐人提成最低1元');
                    return false;
                }else if(book_coverimg == ''){
                    layer.msg('图书封面不能为空');
                    return false;
                }


                var entitydata;
                if(g_id && s_id =='1'){
                    entitydata ={
                        code:goodscode,
                        name:goodsname,
                        original_price:prime_price,
                        author:author,
                        pages:pages,
                        manufactor:press,
                        produce_date:publish_date,
                        image:book_coverimg,
                        price:spot_price,
                        brief:describe,
                        number:stock,
                        referral_fee:referee_deduct,
                        remark:remarks,
                        shop_id:uid,
                        id:g_id,
                        market_type:1,
                        module:'market',
                        method:'market.update',
                        request_mode:'post',
                        key:key,
                        sign:sign,
                        timestamp:timestamp
                    }
                }else if(g_id && s_id =='-1'){
                    entitydata ={
                        code:goodscode,
                        name:goodsname,
                        original_price:prime_price,
                        author:author,
                        pages:pages,
                        manufactor:press,
                        produce_date:publish_date,
                        image:book_coverimg,
                        price:spot_price,
                        brief:describe,
                        number:stock,
                        referral_fee:referee_deduct,
                        remark:remarks,
                        shop_id:uid,
                        id:g_id,
                        status:1,
                        market_type:1,
                        module:'market',
                        method:'market.update',
                        request_mode:'post',
                        key:key,
                        sign:sign,
                        timestamp:timestamp
                    };
                    sessionStorage.setItem('edit_status','1');
                }else if(g_id && s_id =='2'){
                    entitydata ={
                        code:goodscode,
                        name:goodsname,
                        original_price:prime_price,
                        author:author,
                        pages:pages,
                        manufactor:press,
                        produce_date:publish_date,
                        image:book_coverimg,
                        price:spot_price,
                        brief:describe,
                        number:stock,
                        referral_fee:referee_deduct,
                        remark:remarks,
                        shop_id:uid,
                        id:g_id,
                        status:2,
                        market_type:1,
                        module:'market',
                        method:'market.update',
                        request_mode:'post',
                        key:key,
                        sign:sign,
                        timestamp:timestamp
                    };
                    sessionStorage.setItem('edit_status','2');
                }else if(g_id && s_id =='-3'){
                    entitydata ={
                        code:goodscode,
                        name:goodsname,
                        original_price:prime_price,
                        author:author,
                        pages:pages,
                        manufactor:press,
                        produce_date:publish_date,
                        image:book_coverimg,
                        price:spot_price,
                        brief:describe,
                        number:stock,
                        referral_fee:referee_deduct,
                        remark:remarks,
                        shop_id:uid,
                        id:g_id,
                        status:2,
                        market_type:1,
                        module:'market',
                        method:'market.update',
                        request_mode:'post',
                        key:key,
                        sign:sign,
                        timestamp:timestamp
                    };
                    sessionStorage.setItem('edit_status','2');
                }else if(g_id && !s_id){
                    entitydata ={
                        code:goodscode,
                        name:goodsname,
                        original_price:prime_price,
                        author:author,
                        pages:pages,
                        manufactor:press,
                        produce_date:publish_date,
                        image:book_coverimg,
                        price:spot_price,
                        brief:describe,
                        number:stock,
                        referral_fee:referee_deduct,
                        remark:remarks,
                        shop_id:uid,
                        id:g_id,
                        status:'',
                        market_type:1,
                        module:'market',
                        method:'market.update',
                        request_mode:'post',
                        key:key,
                        sign:sign,
                        timestamp:timestamp
                    }
                }else{
                    entitydata ={
                        code:goodscode,
                        name:goodsname,
                        original_price:prime_price,
                        author:author,
                        pages:pages,
                        manufactor:press,
                        produce_date:publish_date,
                        image:book_coverimg,
                        price:spot_price,
                        brief:describe,
                        number:stock,
                        referral_fee:referee_deduct,
                        remark:remarks,
                        shop_id:uid,
                        market_type:1,
                        module:'market',
                        method:'market',
                        request_mode:'post',
                        key:key,
                        sign:sign,
                        timestamp:timestamp
                    };
                    sessionStorage.setItem('edit_status','2');
                }
                $.ajax({
                    type: 'post',
                    url: api+'/api/index',
                    data:entitydata,
                    dataType: 'json',
                    success: function (a) {
                        console.log(a);
                        if (a.status == 'success') {
                            window.location.href='entity.html';
                        }else{
                            layer.alert(a.msg);
                        }
                    }
                });
            })
            $('.phone .delivery_list3 button').eq(1).on('click',function () {
                var p_this=$(this);
                var newphone =  p_this.parents('.delivery_bot').find('.delivery_list2').find('input').val();
                var oldphone = p_this.parents('.delivery_bot').find('.delivery_list').eq(0).find('p').text();
                if(!(/^1(3|4|5|7|8)\d{9}$/.test(newphone))){
                    layer.alert('请输入正确的手机号');
                    return false;
                }else if(newphone == oldphone){
                    layer.alert('手机号未做更改');
                    return false;
                }
                $.ajax({
                    url: api + '/api/index',
                    type:'post',
                    data:{
                        id:'1',
                        code:'123',
                        key:key,
                        method:'message.updateMobile',
                        module:'system',
                        mobile:newphone,
                        request_mode:'post',
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType:'json',
                    success:function(a){
                        if(a.status =='success') {
                            $('.phone').hide();
                            localStorage.setItem('umobile',newphone);
                            p_this.parents('.delivery_bot').find('.delivery_list').eq(0).find('p').text(newphone);
                            p_this.parents('.delivery_bot').find('.delivery_list2').find('input').val('');
                        }else{
                            layer.alert(a.msg)
                        }
                    }
                });
            });
            $('.password2 .delivery_list3 button').eq(1).on('click',function () {
                var ps_this=$(this);
                var password1 = ps_this.parents('.delivery_bot').find('.delivery_list2').eq(0).find('input').val();
                var password2 =  ps_this.parents('.delivery_bot').find('.delivery_list2').eq(1).find('input').val();
                if(password1 == ''){
                    layer.alert('请输入新密码');
                    return false;
                }else if(password1.length <6){
                    layer.alert('请输入6位以上密码');
                    return false;
                }else if(password2 == ''){
                    layer.alert('请输入确认密码');
                    return false;
                }else if(password1 != password2){
                    layer.alert('确认密码和新密码不一致');
                    return false;
                }
                $.ajax({
                    url: api + '/api/index',
                    type:'post',
                    data:{
                        key:key,
                        method:'user.edit_password',
                        module:'member',
                        password:password2,
                        request_mode:'post',
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType:'json',
                    success:function(a){
                        if(a.status =='success') {
                            $('.password2').hide();
                            window.location.href='index.html';
                        }else{
                            layer.alert(a.msg)
                        }
                    }
                });
            });
        });
    })
});