requirejs.config({
    paths:{
        jquery:'jquery-1.7.2.min',
        style:'style',
        template:'template',
        umconfig:'../../editor/umeditor.config',
        umeditor:'../../editor/umeditor.min',
        layui:'layui/layui.all',
        md5:'md5',
        base64:'base64'
    },
    shim: {
        "style":{
            deps: ['jquery']
        },
        "template":{
            deps: ['jquery']
        },
        "umconfig":{
            deps: ['jquery']
        },
        "umeditor":{
            deps: ['jquery']
        },
        "layui":{
            deps: ['jquery']
        },
        "md5":{
            deps: ['jquery']
        }
    }
})