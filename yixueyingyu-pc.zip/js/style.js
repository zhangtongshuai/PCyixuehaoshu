var uid = localStorage.getItem('uid');
if(!uid || uid == ''){
    window.location.href='../index.html';
}
var curTime = localStorage.getItem('curTime');
var nowcurTime = new Date().getTime();
if(nowcurTime-curTime > 43200000){
    localStorage.clear();
    window.location.href='../index.html';
}
$('.login .password').find('a').on('click',function () {
    $('.popup').show();
});
// 点击×关闭这个弹出框
$('.close_popup').on('click',function () {
    $('.popup').hide();
    $(".popup2").hide();
});
$('.popup_con').on('click',function () {
    $('.popup').hide();
});
// 修改手机号弹出框
$("#phone_bd").click(function(){
    // 弹出这个弹出框
    $(".phone").show();
    // 吉祥物突出来的高度
    var PopupConTopHeight2 = $(".phone .popup_con_top img").height();
    $(".phone .popup_con_top img").css("margin-top",-PopupConTopHeight2/2 - 10);
    // 白色部分  的高度要加上吉祥物突出来的高度
    $(".phone .popup_con_con").css("margin-top",PopupConTopHeight2/2 +10);
});
// 修改密码弹出框
$("#admin_xg").click(function(){
    // 弹出这个弹出框
    $(".password2").show();
    // 吉祥物突出来的高度
    var PopupConTopHeight3 = $(".password2 .popup_con_top img").height();
    $(".password2 .popup_con_top img").css("margin-top",-PopupConTopHeight3/2 - 10);
    // 白色部分  的高度要加上吉祥物突出来的高度
    $(".password2 .popup_con_con").css("margin-top",PopupConTopHeight3/2 +10);
});
$(document).on('click','.delivery_list3 .button2',function () {
    $('.popup2').hide();
});
//退出
$('.head_right').find('#quit_btn').on('click',function () {
    localStorage.clear();
    window.location.href='index.html';
});


