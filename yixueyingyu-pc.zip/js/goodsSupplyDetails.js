requirejs(['common'],function(c){
    requirejs(['jquery','validata','base64','template','style'],function ($,validata,base64,template,style) {
        console.log(validata.isEqual(1,2));
        var api = validata.isApi();
        var uid = validata.isUid();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        var uname = localStorage.getItem('uname');
        var uavatar = localStorage.getItem('uavatar');
        var umobile = localStorage.getItem('umobile');
        validata.uinfo(uname,uavatar,umobile);
        layui.use(['form','layer'], function(){
            var form = layui.form
                ,layer = layui.layer;
            function getUrlParam(key) {
                // 获取参数
                var url = window.location.search;
                // 正则筛选地址栏
                var reg = new RegExp("(^|&)" + key + "=([^&]*)(&|$)");
                // 匹配目标参数
                var result = url.substr(1).match(reg);
                //返回参数值
                return result ? decodeURIComponent(result[2]) : null;
            }
            var gid = getUrlParam('gid');
            //分页
            function searchFilter(pageindex){
                var pageNo = getUrlParam('pageIndex');
                if (!pageNo) {
                    pageNo = pageindex;
                }
                $.ajax({
                    url: api + '/api/index?page='+pageNo ,
                    type:'get',
                    data:{
                        key:key,
                        sign:sign,
                        timestamp:timestamp,
                        module:'market',
                        method:'market.contrast.'+gid,
                        request_mode:'get'
                    },
                    dataType:'json',
                    success:function(a){
                        console.log(a);
                        if(a.status =='success') {
                            $('.goodsSupplyDetails .goods_details .goods_details_left img').attr('src',a.result.image);
                            $('.goodsSupplyDetails .goods_details .goods_details_right p').eq(0).html(a.result.name);
                            $('.goodsSupplyDetails .goods_details .goods_details_right p').eq(1).html(a.result.code);
                            if(a.result.acticles){
                                var soft_text = '';
                                for(var i=0;i<a.result.acticles.length;i++){
                                    soft_text += '<li class="fl"><a href="'+a.result.acticles[i].link+'">软文'+i+'</a></li>'
                                }
                                $('.goods_details .goods_details_right').find('ul').append(soft_text);
                            }
                            var goods = a.result.depot_many_markets;
                            for(var i=0;i<goods.length;i++){
                                var base = new Base64();
                                var rp = goods[i].id+'/'+uid;
                                var referee = base.encode(rp);
                                goods[i].referee =  referee;
                            }
                            var html1=template('tpl_translation_goodsdetails_list',goods);
                            document.getElementById('translation_goodsdetails_list').innerHTML=html1;
                            if(goods==''|| goods ==null){
                                $('#kkpager').hide();
                            }
                            //生成分页
                            kkpager.generPageHtml({
                                pno: pageNo,
                                //总页码
                                total : a.pageTotal,
                                //总数据条数
                                totalRecords : a.total,
                                mode : 'click',
                                click : function(n){
                                    this.selectPage(pageNo);
                                    searchPage(n);
                                    return false;
                                }
                            },true);
                        }else{
                            layer.alert(a.msg)
                            $('#kkpager').hide();
                        }
                    }
                });
            }
            //init
            $(function () {
                searchFilter(1)
            });
            //ajax翻页
            function searchPage(n) {
                searchFilter(n);
            }

            $('.phone .delivery_list3 button').eq(1).on('click',function () {
                var p_this=$(this);
                var newphone =  p_this.parents('.delivery_bot').find('.delivery_list2').find('input').val();
                var oldphone = p_this.parents('.delivery_bot').find('.delivery_list').eq(0).find('p').text();
                if(!(/^1(3|4|5|7|8)\d{9}$/.test(newphone))){
                    layer.alert('请输入正确的手机号');
                    return false;
                }else if(newphone == oldphone){
                    layer.alert('手机号未做更改');
                    return false;
                }
                $.ajax({
                    url: api + '/api/index',
                    type:'post',
                    data:{
                        id:'1',
                        code:'123',
                        key:key,
                        method:'message.updateMobile',
                        module:'system',
                        mobile:newphone,
                        request_mode:'post',
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType:'json',
                    success:function(a){
                        if(a.status =='success') {
                            $('.phone').hide();
                            localStorage.setItem('umobile',newphone);
                            p_this.parents('.delivery_bot').find('.delivery_list').eq(0).find('p').text(newphone);
                            p_this.parents('.delivery_bot').find('.delivery_list2').find('input').val('');
                        }else{
                            layer.alert(a.msg)
                        }
                    }
                });
            });
            $('.password2 .delivery_list3 button').eq(1).on('click',function () {
                var ps_this=$(this);
                var password1 = ps_this.parents('.delivery_bot').find('.delivery_list2').eq(0).find('input').val();
                var password2 =  ps_this.parents('.delivery_bot').find('.delivery_list2').eq(1).find('input').val();
                if(password1 == ''){
                    layer.alert('请输入新密码');
                    return false;
                }else if(password1.length <6){
                    layer.alert('请输入6位以上密码');
                    return false;
                }else if(password2 == ''){
                    layer.alert('请输入确认密码');
                    return false;
                }else if(password1 != password2){
                    layer.alert('确认密码和新密码不一致');
                    return false;
                }
                $.ajax({
                    url: api + '/api/index',
                    type:'post',
                    data:{
                        key:key,
                        method:'user.edit_password',
                        module:'member',
                        password:password2,
                        request_mode:'post',
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType:'json',
                    success:function(a){
                        if(a.status =='success') {
                            $('.password2').hide();
                            window.location.href='index.html';
                        }else{
                            layer.alert(a.msg)
                        }
                    }
                });
            });
        });
    })
});