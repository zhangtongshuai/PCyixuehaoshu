requirejs(['common'],function(c){
    requirejs(['jquery','validata'],function ($,validata) {
        console.log(validata.isEqual(1,2))
        var api = validata.isApi();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        $('.login .password').find('a').on('click',function () {
            $('.popup').show();
        });
        // 点击×关闭这个弹出框
        $('.close_popup').on('click',function () {
            $('.popup').hide();
        });
        $('.popup_con').on('click',function () {
            $('.popup').hide();
        });
        layui.use(['form','laydate','layer','element'], function(){
            var layer = layui.layer
            $('.login').find('.button').on('click',function () {
                var mobile = $('.login').find('.mobile').val();
                var password = $('.login').find('.login_password').val();
                var reg=/[^0-9]/g;
                var len=mobile.length;
                if(mobile == ''){
                    layer.alert("用户名不能为空");
                    return false;
                }else if(len!=11) {
                    layer.alert("您输入的手机号码位数不正确！");
                    return false;
                } else if(reg.test(mobile)) {
                    layer.alert("手机号码必须是数字！");
                    return false;
                }else if(password == ''){
                    layer.alert("密码不能为空");
                    return false;
                }
                $.ajax({
                    type: 'post',
                    url: api+'/api/index',
                    data:{
                        mobile:mobile,
                        password:password,
                        module:'member',
                        method:'user.login',
                        request_mode:'post',
                        key:key,
                        sign:sign,
                        timestamp:timestamp
                    },
                    dataType: 'json',
                    success: function (a) {
                        console.log(a);
                        if(a.status =='success') {
                            var curTime = new Date().getTime();
                            localStorage.setItem('curTime',curTime);
                            localStorage.setItem('uid',a.result.uid);
                            localStorage.setItem('uname',a.result.name);
                            localStorage.setItem('uavatar',a.result.avatar);
                            localStorage.setItem('umobile',a.result.mobile);
                            localStorage.setItem('role',a.result.role);
                            if(a.result.role == 3){
                                window.location.href='order.html';
                            }else if(a.result.role == 4){
                                window.location.href='refereeorder.html';
                            }
                        }else{
                            layer.alert(a.msg)
                        }
                    },
                    error: function(XMLHttpRequest, textStatus, errorThrown) {
                        // alert(XMLHttpRequest.status);
                        // alert(XMLHttpRequest.readyState);
                        // alert(textStatus);
                    }
                });
            });

        });
    })
});