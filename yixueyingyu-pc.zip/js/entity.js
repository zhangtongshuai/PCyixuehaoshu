requirejs(['common'],function(c){
    requirejs(['jquery','validata','template','style'],function ($,validata,template,style) {
        console.log(validata.isEqual(1,2))
        var api = validata.isApi();
        var uid = validata.isUid();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        var uname = localStorage.getItem('uname');
        var uavatar = localStorage.getItem('uavatar');
        var umobile = localStorage.getItem('umobile');
        var edit_status = sessionStorage.getItem('edit_status');
        validata.uinfo(uname,uavatar,umobile);
        var goodstatus = 1;
        var name = '';
        var surl = '';
        layui.use(['form','laydate','layer','element'], function(){
            var form = layui.form
                ,layer = layui.layer
                ,laydate = layui.laydate
                ,element = layui.element
            //执行一个laydate实例
            laydate.render({
                elem: '#test1'
            });
            laydate.render({
                elem: '#test2'
            });
            function g_data(name,goodstatus) {
                return goodsdata = {
                    module:'market',
                    method:'market.shop.lists',
                    request_mode:'get',
                    name:name,
                    sequence:'DESC',
                    shop_id:uid,
                    status:goodstatus,
                    key:key,
                    sign:sign,
                    timestamp:timestamp
                }
            }
            if(!edit_status){
                goodslist(g_data(name,goodstatus));
            }else{
                goodstatus = edit_status;
                name = '';
                $('#translation_goods_list').html('');
                if(goodstatus == 1){
                    $('.goods_list .layui-tab-title li').removeClass('layui-this');
                    $('.goods_list .layui-tab-title li').eq(0).addClass('layui-this');
                }else if(goodstatus == -1){
                    $('.goods_list .layui-tab-title li').removeClass('layui-this');
                    $('.goods_list .layui-tab-title li').eq(1).addClass('layui-this');
                }else if(goodstatus == 2){
                    $('.goods_list .layui-tab-title li').removeClass('layui-this');
                    $('.goods_list .layui-tab-title li').eq(2).addClass('layui-this');
                }else if(goodstatus == -3){
                    $('.goods_list .layui-tab-title li').removeClass('layui-this');
                    $('.goods_list .layui-tab-title li').eq(3).addClass('layui-this');
                }
                goodslist(g_data(name,goodstatus));
            }
            window.addEventListener("beforeunload", function(e) {
                sessionStorage.clear();
            });
            $('.goods_list .layui-tab-title li').eq(0).on('click',function () {
                sessionStorage.clear();
                goodstatus = 1;
                name = '';
                $('#translation_goods_list').html('');
                goodslist(g_data(name,goodstatus));
            });
            $('.goods_list .layui-tab-title li').eq(1).on('click',function () {
                sessionStorage.clear();
                goodstatus = -1;
                name = '';
                $('#translation_goods_list').html('');
                goodslist(g_data(name,goodstatus));
            });
            $('.goods_list .layui-tab-title li').eq(2).on('click',function () {
                sessionStorage.clear();
                goodstatus = 2;
                name = '';
                $('#translation_goods_list').html('');
                goodslist(g_data(name,goodstatus));
            });
            $('.goods_list .layui-tab-title li').eq(3).on('click',function () {
                sessionStorage.clear();
                goodstatus = -3;
                name = '';
                $('#translation_goods_list').html('');
                goodslist(g_data(name,goodstatus));
            });
            $('.query_btn').on('click',function () {
                sessionStorage.clear();
                var searchinfo = $('.order_search_info').val();
                if(searchinfo == ''){
                    layer.alert('没有输入内容');
                    return false;
                }
                name = searchinfo;
                goodstatus = $('.goods_list .layui-tab-title .layui-this').attr('status');
                $('#translation_goods_list').html('');
                goodslist(g_data(name,goodstatus));
            });
            var stockstatus = 1;
            $('.goods_list .layui-tab-content thead tr th').eq(2).on('click',function () {
                sessionStorage.clear();
                surl = '&order_by_field=number';
                if(stockstatus == 1){
                    var goodsdata1 = {
                        module:'market',
                        method:'market.shop.lists',
                        request_mode:'get',
                        name:name,
                        sequence:'ASC',
                        shop_id:uid,
                        status:goodstatus,
                        key:key,
                        sign:sign,
                        timestamp:timestamp
                    };
                    $('#translation_goods_list').html('');
                    goodslist(goodsdata1);
                    stockstatus = 0;
                }else if(stockstatus == 0){
                    var goodsdata1 = {
                        module:'market',
                        method:'market.shop.lists',
                        request_mode:'get',
                        name:name,
                        sequence:'DESC',
                        shop_id:uid,
                        status:goodstatus,
                        key:key,
                        sign:sign,
                        timestamp:timestamp
                    };
                    $('#translation_goods_list').html('');
                    goodslist(goodsdata1);
                    stockstatus = 1;
                }
            });
            var sales_status =1;
            $('.goods_list .layui-tab-content thead tr th').eq(3).on('click',function () {
                sessionStorage.clear();
                surl = '&order_by_field=sales_number';
                if(sales_status == 1){
                    var goodsdata1 = {
                        module:'market',
                        method:'market.shop.lists',
                        request_mode:'get',
                        name:name,
                        sequence:'ASC',
                        shop_id:uid,
                        status:goodstatus,
                        key:key,
                        sign:sign,
                        timestamp:timestamp
                    };
                    $('#translation_goods_list').html('');
                    goodslist(goodsdata1);
                    sales_status = 0;
                }else if(sales_status == 0){
                    var goodsdata1 = {
                        module:'market',
                        method:'market.shop.lists',
                        request_mode:'get',
                        name:name,
                        sequence:'DESC',
                        shop_id:uid,
                        status:goodstatus,
                        key:key,
                        sign:sign,
                        timestamp:timestamp
                    };
                    $('#translation_goods_list').html('');
                    goodslist(goodsdata1);
                    sales_status = 1;
                }
            });
            var create_status =1;
            $('.goods_list .layui-tab-content thead tr th').eq(4).on('click',function () {
                sessionStorage.clear();
                surl = '&order_by_field=sales_number';
                if(create_status == 1){
                    var goodsdata1 = {
                        module:'market',
                        method:'market.shop.lists',
                        request_mode:'get',
                        name:name,
                        sequence:'ASC',
                        shop_id:uid,
                        status:goodstatus,
                        key:key,
                        sign:sign,
                        timestamp:timestamp
                    };
                    $('#translation_goods_list').html('');
                    goodslist(goodsdata1);
                    create_status = 0;
                }else if(create_status == 0){
                    var goodsdata1 = {
                        module:'market',
                        method:'market.shop.lists',
                        request_mode:'get',
                        name:name,
                        sequence:'DESC',
                        shop_id:uid,
                        status:goodstatus,
                        key:key,
                        sign:sign,
                        timestamp:timestamp
                    };
                    $('#translation_goods_list').html('');
                    goodslist(goodsdata1);
                    create_status = 1;
                }
            });
            function getUrlParam(key) {
                // 获取参数
                var url = window.location.search;
                // 正则筛选地址栏
                var reg = new RegExp("(^|&)" + key + "=([^&]*)(&|$)");
                // 匹配目标参数
                var result = url.substr(1).match(reg);
                //返回参数值
                return result ? decodeURIComponent(result[2]) : null;
            }
            function timestampToTime(timestamp) {
                var date = new Date(timestamp);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
                var Y = date.getFullYear() + '-';
                var M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
                var D = date.getDate()<10?'0'+date.getDate():date.getDate();
                return Y+M+D;
            }
            //分页
            function goodslist(goodsdata) {
                function searchFilter(pageindex){
                    var pageNo = getUrlParam('pageIndex');
                    if (!pageNo) {
                        pageNo = pageindex;
                    }
                    $.ajax({
                        url: api+'/api/index?page='+pageNo+surl,
                        type:'post',
                        data:goodsdata,
                        dataType:'json',
                        success:function(a){
                            // console.log(re);
                            if(a.status =='success') {
                                var goods = a.result;
                                if(goods==''|| goods ==null){
                                    $('#kkpager').hide();
                                }else{
                                    $('#kkpager').show();
                                }
                                for(var i=0;i<goods.length;i++){
                                    var t = goods[i].update_time;
                                    t = Date.parse(t.replace(/-/g,"/"));
                                    var T = new Date(t);
                                    var ct = T.getTime();
                                    goods[i].update_time=timestampToTime(ct);
                                }
                                var html1=template('tpl_translation_goods_list',goods);
                                document.getElementById('translation_goods_list').innerHTML=html1;
                                //生成分页
                                kkpager.generPageHtml({
                                    pno: pageNo,
                                    //总页码
                                    total : a.pageTotal,
                                    //总数据条数
                                    totalRecords : a.total,
                                    mode : 'click',
                                    click : function(n){
                                        this.selectPage(pageNo);
                                        searchPage(n);
                                        return false;
                                    }
                                },true);
                            }else{
                                layer.alert(a.msg);
                                $('#kkpager').hide();
                            }
                        }
                    });
                }
                //init
                $(function () {
                    searchFilter(1)
                });
                //ajax翻页
                function searchPage(n) {
                    searchFilter(n);
                }
            }
            //下架
            $(document).on('click','.down_btn',function () {
                var g_this = $(this);
                var market_id = g_this.parents('tr').attr('good_id');
                $.ajax({
                    url: api+'/api/index',
                    type:'post',
                    data:{
                        market_id:market_id,
                        module:'market',
                        method:'market.pullOffShelves',
                        request_mode:'post',
                        shop_id:uid,
                        key:key,
                        sign:sign,
                        timestamp:timestamp
                    },
                    dataType:'json',
                    success:function(a){
                        if(a.status =='success') {
                            layer.msg('下架成功')
                            g_this.parents('tr').remove();
                        }else{
                            layer.alert(a.msg)
                        }
                    }
                });
            })
            //删除
            $(document).on('click','.delete_btn',function () {
                var g_this = $(this);
                var market_id = g_this.parents('tr').attr('good_id');
                layer.confirm('是否确定删除该商品', {
                    btn: ['确定', '取消'] //可以无限个按钮
                }, function(index, layero){
                    $.ajax({
                        url: api+'/api/index',
                        type:'post',
                        data:{
                            market_id:market_id,
                            module:'market',
                            method:'market.delete',
                            request_mode:'post',
                            shop_id:uid,
                            key:key,
                            sign:sign,
                            timestamp:timestamp
                        },
                        dataType:'json',
                        success:function(a){
                            if(a.status =='success') {
                                layer.msg('删除成功');
                                g_this.parents('tr').remove();
                            }else{
                                layer.alert(a.msg)
                            }
                        }
                    });
                }, function(index){
                    //按钮【按钮二】的回调
                });
            });
            $('.phone .delivery_list3 button').eq(1).on('click',function () {
                var p_this=$(this);
                var newphone =  p_this.parents('.delivery_bot').find('.delivery_list2').find('input').val();
                var oldphone = p_this.parents('.delivery_bot').find('.delivery_list').eq(0).find('p').text();
                if(!(/^1(3|4|5|7|8)\d{9}$/.test(newphone))){
                    layer.alert('请输入正确的手机号');
                    return false;
                }else if(newphone == oldphone){
                    layer.alert('手机号未做更改');
                    return false;
                }
                $.ajax({
                    url: api + '/api/index',
                    type:'post',
                    data:{
                        id:'1',
                        code:'123',
                        key:key,
                        method:'message.updateMobile',
                        module:'system',
                        mobile:newphone,
                        request_mode:'post',
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType:'json',
                    success:function(a){
                        if(a.status =='success') {
                            $('.phone').hide();
                            localStorage.setItem('umobile',newphone);
                            p_this.parents('.delivery_bot').find('.delivery_list').eq(0).find('p').text(newphone);
                            p_this.parents('.delivery_bot').find('.delivery_list2').find('input').val('');
                        }else{
                            layer.alert(a.msg)
                        }
                    }
                });
            });
            $('.password2 .delivery_list3 button').eq(1).on('click',function () {
                var ps_this=$(this);
                var password1 = ps_this.parents('.delivery_bot').find('.delivery_list2').eq(0).find('input').val();
                var password2 =  ps_this.parents('.delivery_bot').find('.delivery_list2').eq(1).find('input').val();
                if(password1 == ''){
                    layer.alert('请输入新密码');
                    return false;
                }else if(password1.length <6){
                    layer.alert('请输入6位以上密码');
                    return false;
                }else if(password2 == ''){
                    layer.alert('请输入确认密码');
                    return false;
                }else if(password1 != password2){
                    layer.alert('确认密码和新密码不一致');
                    return false;
                }
                $.ajax({
                    url: api + '/api/index',
                    type:'post',
                    data:{
                        key:key,
                        method:'user.edit_password',
                        module:'member',
                        password:password2,
                        request_mode:'post',
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType:'json',
                    success:function(a){
                        if(a.status =='success') {
                            $('.password2').hide();
                            window.location.href='index.html';
                        }else{
                            layer.alert(a.msg)
                        }
                    }
                });
            });
        });
    })
});