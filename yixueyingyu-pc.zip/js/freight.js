requirejs(['common'],function(c){
    requirejs(['jquery','validata','style'],function ($,validata,style) {
        var api = validata.isApi();
        var uid = validata.isUid();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        var uname = localStorage.getItem('uname');
        var uavatar = localStorage.getItem('uavatar');
        var umobile = localStorage.getItem('umobile');
        validata.uinfo(uname,uavatar,umobile);
        layui.use('layer', function(){
            var layer = layui.layer;
            $('.freight .whole_freight .edit_btn').on('click',function () {
                $(this).hide();
                $('.freight .whole_freight .hold_btn').show();
                $('.freight .whole_freight input').removeAttr('readonly');
                $('.freight .whole_freight input').css('border','1px solid #ddd');
            })
            $('.freight .whole_freight .hold_btn').on('click',function () {
                $(this).hide();
                $('.freight .whole_freight .edit_btn').show();
                $('.freight .whole_freight input').attr('readonly','flase');
                $('.freight .whole_freight input').css('border','none');
                var base_fee = $('.freight .whole_freight .base_freight').val();
                var max_fee = $('.freight .whole_freight .exemption_freight_line').val();
                var fee_id = $('.freight .whole_freight').attr('fee_id');
                $.ajax({
                    type: "post",
                    url: api+'/api/index',
                    data:{
                        base_fee:base_fee,
                        max_fee:max_fee,
                        fee_id:fee_id,
                        module:'member',
                        method:'shop.update_fee',
                        request_mode:'post',
                        key:key,
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType: 'json',
                    success: function (b) {
                        if(b.status == 'success'){
                            layer.msg('保存成功')
                        }else{
                            layer.msg(b.msg)
                        }
                    }
                })
            })
            $('.freight .province_freight .edit_btn').on('click',function () {
                $(this).hide();
                $('.freight .province_freight .hold_btn').show();
                $('.freight .province_freight input').removeAttr('readonly');
                $('.freight .province_freight input').css('border','1px solid #ddd');
                $('.freight .special_province .province_info').css('border','1px solid #f70');
                $('.freight .special_province .province_info').addClass('delete_province');
                $('.freight .special_province .province_info span').show();
                $('.freight .province_list').show();
            })
            $('.freight .province_freight .hold_btn').on('click',function () {
                $(this).hide();
                $('.freight .province_freight .edit_btn').show();
                $('.freight .province_freight input').attr('readonly','flase');
                $('.freight .province_freight input').css('border','none');
                $('.freight .special_province .province_info').css('border','none');
                $('.freight .special_province .province_info').removeClass('delete_province');
                $('.freight .special_province .province_info span').hide();
                $('.freight .province_list').hide();
                var base_fee = $('.freight .province_freight .base_freight').val();
                var max_fee = $('.freight .province_freight .exemption_freight_line').val();
                var fee_id = $('.freight .province_freight').attr('fee_id');
                $.ajax({
                    type: "post",
                    url: api+'/api/index',
                    data:{
                        base_fee:base_fee,
                        max_fee:max_fee,
                        fee_id:fee_id,
                        module:'member',
                        method:'shop.update_fee',
                        request_mode:'post',
                        key:key,
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType: 'json',
                    success: function (b) {
                        if(b.status == 'success'){
                            layer.msg('保存成功')
                        }else{
                            layer.msg(b.msg)
                        }
                    }
                })
            });
            $('.freight .city_freight .edit_btn').on('click',function () {
                $(this).hide();
                $('.freight .city_freight .hold_btn').show();
                $('.freight .city_freight input').removeAttr('readonly');
                $('.freight .city_freight input').css('border','1px solid #ddd');
                $('.freight .special_city .city_info').css('border','1px solid #f70');
                $('.freight .special_city .city_info').addClass('delete_city');
                $('.freight .special_city .city_info span').show();
                $('.freight .city_list').show();
            })
            $('.freight .city_freight .hold_btn').on('click',function () {
                $(this).hide();
                $('.freight .city_freight .edit_btn').show();
                $('.freight .city_freight input').attr('readonly','flase');
                $('.freight .city_freight input').css('border','none');
                $('.freight .special_city .city_info').css('border','none');
                $('.freight .special_city .city_info').removeClass('delete_city');
                $('.freight .special_city .city_info span').hide();
                $('.freight .city_list').hide();
                var base_fee = $('.freight .city_freight .base_freight').val();
                var max_fee = $('.freight .city_freight .exemption_freight_line').val();
                var fee_id = $('.freight .city_freight').attr('fee_id');
                $.ajax({
                    type: "post",
                    url: api+'/api/index',
                    data:{
                        base_fee:base_fee,
                        max_fee:max_fee,
                        fee_id:fee_id,
                        module:'member',
                        method:'shop.update_fee',
                        request_mode:'post',
                        key:key,
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType: 'json',
                    success: function (b) {
                        if(b.status == 'success'){
                            layer.msg('保存成功')
                        }else{
                            layer.msg(b.msg)
                        }
                    }
                })
            })

            $.ajax({
                url: api+'/api/index',
                type:'post',
                data:{
                    key:key,
                    sign:sign,
                    timestamp:timestamp,
                    method:'address.get_province',
                    module:'member',
                    request_mode:'post'
                },
                dataType:'json',
                success:function(a){
                    if(a.status =='success') {
                        var provinces='<option value="">选择省份</option>';
                        for(var i=0;i<a.result.length;i++){
                            provinces +='<option value="'+a.result[i].id+'">'+a.result[i].district_name+'</option>';
                        }
                        $('.freight .province_list .provinces').append(provinces);
                        $('.freight .city_list .provinces').append(provinces);
                    }else{
                        layer.alert(a.msg)
                    }
                }
            });
            $.ajax({
                url: api+'/api/index',
                type:'get',
                data:{
                    key:key,
                    sign:sign,
                    timestamp:timestamp,
                    method:'shop.get_fee',
                    module:'member',
                    request_mode:'get',
                    uid:uid
                },
                dataType:'json',
                success:function(a){
                    if(a.status =='success') {
                        $('.freight .whole_freight .base_freight').val(a.result[0].base_fee);
                        $('.freight .whole_freight .exemption_freight_line').val(a.result[0].max_fee);
                        $('.freight .whole_freight').attr('fee_id',a.result[0].id);
                        $('.freight .special_province_freight .province_freight .base_freight').val(a.result[1].base_fee);
                        $('.freight .special_province_freight .province_freight .exemption_freight_line').val(a.result[1].max_fee);
                        $('.freight .special_province_freight .province_freight').attr('fee_id',a.result[1].id);
                        $('.freight .special_city_freight .city_freight .base_freight').val(a.result[2].base_fee);
                        $('.freight .special_city_freight .city_freight .exemption_freight_line').val(a.result[2].max_fee);
                        $('.freight .special_city_freight .city_freight').attr('fee_id',a.result[2].id);
                        var special_province = '';
                        var special_city = '';
                        if(a.result[1].fee_info!=''){
                            for(var i=0;i<a.result[1].fee_info.length;i++){
                                special_province+='<li class="fl" pid="'+a.result[1].fee_info[i].id+'" fee_id="'+a.result[1].fee_info[i].fee_id+'" province_id="'+a.result[1].fee_info[i].province_id+'" city_id="'+a.result[1].fee_info[i].city_id+'"><div class="province_info"><b>'+a.result[1].fee_info[i].province_name+'</b><span>×</span></div></li>';
                            }
                            $('.special_province_freight .special_province_list ul').append(special_province);
                        }
                        if(a.result[2].fee_info!=''){
                            for(var i=0;i<a.result[2].fee_info.length;i++){
                                special_city+='<li class="fl" pid="'+a.result[2].fee_info[i].id+'" fee_id="'+a.result[2].fee_info[i].fee_id+'" province_id="'+a.result[2].fee_info[i].province_id+'" city_id="'+a.result[2].fee_info[i].city_id+'"><div class="city_info"><b>'+a.result[2].fee_info[i].city_name+'</b><span>×</span></div></li>';
                            }
                            $('.special_city_freight .special_city_list ul').append(special_city);
                        }
                    }else{
                        layer.alert(a.msg)
                    }
                }
            });
            $('.special_province_freight .province_list .add_btn').on('click',function () {
                var sp=0;
                var pvalue = $('.special_province_freight .province_list .provinces option:checked').attr('value');
                if(pvalue == ''){
                    layer.alert('没有选择省份');
                    return false;
                }
                $('.special_province_list ul li').each(function () {
                    if(pvalue == $(this).attr('province_id')){
                        sp=1;
                        return false;
                    }
                });
                if(sp==0){
                    var pval = $('.special_province_freight .province_list .provinces option:checked').text();
                    var fee_id = $('.freight .province_freight').attr('fee_id');
                    $.ajax({
                        type: "post",
                        url: api+'/api/index',
                        data:{
                            city_id:0,
                            city_name:'',
                            fee_id:fee_id,
                            province_id:pvalue,
                            province_name:pval,
                            module:'member',
                            method:'shop.store_fee_info',
                            request_mode:'post',
                            key:key,
                            sign:sign,
                            timestamp:timestamp,
                            uid:uid
                        },
                        dataType: 'json',
                        success: function (b) {
                            if(b.status == 'success'){
                                var special_p='<li class="fl" pid="'+b.result.id+'" fee_id="'+fee_id+'" province_id="'+pvalue+'" city_id="0"><div class="province_info delete_province" style="border: 1px solid #f70;"><b>'+pval+'</b><span style="display: inline;">×</span></div></li>';
                                $('.special_province_freight .special_province_list ul').append(special_p);
                            }else{
                                layer.msg(b.msg);
                            }
                        }
                    })
                }
            });
            $('.special_city_freight .city_list .add_btn').on('click',function () {
                var sp=0;
                var pvalue = $('.special_city_freight .city_list .provinces option:checked').attr('value');
                if(pvalue == ''){
                    layer.alert('没有选择省份');
                    return false;
                }
                var cvalue = $('.special_city_freight .city_list .citys option:checked').attr('value');
                if(cvalue == ''){
                    layer.alert('没有选择城市');
                    return false;
                }
                $('.special_city_list ul li').each(function () {
                    if(cvalue == $(this).attr('city_id')){
                        sp=1;
                        return false;
                    }
                });
                if(sp==0){
                    var pval = $('.special_city_freight .city_list .provinces option:checked').text();
                    var cval = $('.special_city_freight .city_list .citys option:checked').text();
                    var fee_id = $('.freight .city_freight').attr('fee_id');
                    $.ajax({
                        type: "post",
                        url: api+'/api/index',
                        data:{
                            city_id:cvalue,
                            city_name:cval,
                            fee_id:fee_id,
                            province_id:pvalue,
                            province_name:pval,
                            module:'member',
                            method:'shop.store_fee_info',
                            request_mode:'post',
                            key:key,
                            sign:sign,
                            timestamp:timestamp,
                            uid:uid
                        },
                        dataType: 'json',
                        success: function (b) {
                            if(b.status == 'success'){
                                var special_c='<li class="fl" pid="'+b.result.id+'" fee_id="'+fee_id+'" province_id="'+pvalue+'" city_id="'+cvalue+'"><div class="city_info delete_city" style="border: 1px solid #f70;"><b>'+cval+'</b><span style="display: inline;">×</span></div></li>';
                                $('.special_city_freight .special_city_list ul').append(special_c);
                            }else{
                                layer.msg(b.msg);
                            }
                        }
                    })
                }
            });
            $(document).on('click','.special_province_list .delete_province',function () {
                var l_this = $(this);
                var fee_info_id = l_this.parents('li').attr('pid');
                $.ajax({
                    type: "post",
                    url: api+'/api/index',
                    data:{
                        fee_info_id:fee_info_id,
                        module:'member',
                        method:'shop.delete_fee_info',
                        request_mode:'post',
                        key:key,
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType: 'json',
                    success: function (b) {
                        if(b.status == 'success'){
                            l_this.parents('li').remove();
                        }else{
                            layer.msg(b.msg);
                        }
                    }
                })
            });
            $(document).on('click','.special_city_list .delete_city',function () {
                var l_this = $(this);
                var fee_info_id = l_this.parents('li').attr('pid');
                $.ajax({
                    type: "post",
                    url: api+'/api/index',
                    data:{
                        fee_info_id:fee_info_id,
                        module:'member',
                        method:'shop.delete_fee_info',
                        request_mode:'post',
                        key:key,
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType: 'json',
                    success: function (b) {
                        if(b.status == 'success'){
                            l_this.parents('li').remove();
                        }else{
                            layer.msg(b.msg);
                        }
                    }
                })
            });
            function select1() {
                var options = '<option value="">选择省份</option>';
                $.ajax({
                    type: "post",
                    url: api+'/api/index',
                    data:{
                        module:'member',
                        method:'address.get_province',
                        request_mode:'post',
                        key:key,
                        sign:sign,
                        timestamp:timestamp
                    },
                    dataType: 'json',
                    success: function (b) {
                        for(var i=0; i<b.result.length; i++){
                            options += '<option value="'+b.result[i].id+'">'+b.result[i].district_name+'</option>'
                        }
                        $('.freight .special_city_freight .city_list .provinces').html(options);
                        select2();
                    }
                })
            }
            function select2() {
                var citys = '<option value="">选择城市</option>';
                $('.freight .special_city_freight .city_list .citys').html('');
                var options=$(".freight .special_city_freight .provinces option:selected");
                var pid = options.attr("value");
                if(pid == ''){
                    return false;
                }
                $.ajax({
                    async:false,
                    type: "post",
                    url: api+'/api/index?pid='+pid,
                    data:{
                        module:'member',
                        method:'address.get_city',
                        request_mode:'post',
                        key:key,
                        sign:sign,
                        timestamp:timestamp
                    },
                    success: function (c) {
                        for(var j=0;j<c.result.length; j++){
                            citys += '<option value="'+c.result[j].id+'">'+c.result[j].district_name+'</option>'
                        }
                        $('.freight .special_city_freight .city_list .citys').html(citys);
                    }
                })
            }
            $(function () {
                $('.freight .special_city_freight .city_list .provinces').bind("change", select2);
            });
            $('.phone .delivery_list3 button').eq(1).on('click',function () {
                var p_this=$(this);
                var newphone =  p_this.parents('.delivery_bot').find('.delivery_list2').find('input').val();
                var oldphone = p_this.parents('.delivery_bot').find('.delivery_list').eq(0).find('p').text();
                if(!(/^1(3|4|5|7|8)\d{9}$/.test(newphone))){
                    layer.alert('请输入正确的手机号');
                    return false;
                }else if(newphone == oldphone){
                    layer.alert('手机号未做更改');
                    return false;
                }
                $.ajax({
                    url: api + '/api/index',
                    type:'post',
                    data:{
                        id:'1',
                        code:'123',
                        key:key,
                        method:'message.updateMobile',
                        module:'system',
                        mobile:newphone,
                        request_mode:'post',
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType:'json',
                    success:function(a){
                        if(a.status =='success') {
                            $('.phone').hide();
                            localStorage.setItem('umobile',newphone);
                            p_this.parents('.delivery_bot').find('.delivery_list').eq(0).find('p').text(newphone);
                            p_this.parents('.delivery_bot').find('.delivery_list2').find('input').val('');
                        }else{
                            layer.alert(a.msg)
                        }
                    }
                });
            });
            $('.password2 .delivery_list3 button').eq(1).on('click',function () {
                var ps_this=$(this);
                var password1 = ps_this.parents('.delivery_bot').find('.delivery_list2').eq(0).find('input').val();
                var password2 =  ps_this.parents('.delivery_bot').find('.delivery_list2').eq(1).find('input').val();
                if(password1 == ''){
                    layer.alert('请输入新密码');
                    return false;
                }else if(password1.length <6){
                    layer.alert('请输入6位以上密码');
                    return false;
                }else if(password2 == ''){
                    layer.alert('请输入确认密码');
                    return false;
                }else if(password1 != password2){
                    layer.alert('确认密码和新密码不一致');
                    return false;
                }
                $.ajax({
                    url: api + '/api/index',
                    type:'post',
                    data:{
                        key:key,
                        method:'user.edit_password',
                        module:'member',
                        password:password2,
                        request_mode:'post',
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType:'json',
                    success:function(a){
                        if(a.status =='success') {
                            $('.password2').hide();
                            window.location.href='index.html';
                        }else{
                            layer.alert(a.msg)
                        }
                    }
                });
            });
        });
    })
});