requirejs(['common'],function(c){
    requirejs(['jquery','validata','style'],function ($,validata,style) {
        var api = validata.isApi();
        var uid = validata.isUid();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        var uname = localStorage.getItem('uname');
        var uavatar = localStorage.getItem('uavatar');
        var umobile = localStorage.getItem('umobile');
        validata.uinfo(uname,uavatar,umobile);
        layui.use('layer', function(){
            var layer = layui.layer;
            function timestampToTime(timestamp) {
                var date = new Date(timestamp);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
                var Y = date.getFullYear() + '年';
                var M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1)+ '月';
                return Y+M;
            }
            function getUrlParam(key) {
                // 获取参数
                var url = window.location.search;
                // 正则筛选地址栏
                var reg = new RegExp("(^|&)" + key + "=([^&]*)(&|$)");
                // 匹配目标参数
                var result = url.substr(1).match(reg);
                //返回参数值
                return result ? decodeURIComponent(result[2]) : null;
            }
            function searchFilter(pageindex){
                var pageNo = getUrlParam('pageIndex');
                if (!pageNo) {
                    pageNo = pageindex;
                }
                $.ajax({
                    url: api+'/api/index?page='+pageNo,
                    type:'get',
                    data:{
                        module:'member',
                        method:'user.show_account',
                        request_mode:'get',
                        key:key,
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType:'json',
                    success:function(a){
                        // console.log(re);
                        if(a.status =='success') {
                            var incomes = a.result;
                            if(incomes == ''){
                                layer.alert('没有信息');
                            }
                            var incomes_list ='';
                            for(var i=0;i<incomes.length;i++){
                                var status = '';//状态
                                if(incomes[i].status==1){
                                    status ='未打款';
                                }else if(incomes[i].status==2){
                                    status ='已打款';
                                }
                                var amount='';//打款金额
                                if(incomes[i].transfer == null){
                                    amount='';
                                }else{
                                    amount='￥'+incomes[i].transfer.amount;
                                }
                                var payee = '';
                                if(incomes[i].transfer == null){
                                    payee='';
                                }else{
                                    if(payee=incomes[i].transfer.payee_account != null){
                                        payee=incomes[i].transfer.payee_account;
                                    }else{
                                        payee='';
                                    }
                                }
                                var create_time='';
                                if(incomes[i].transfer == null){
                                    create_time='';
                                }else{
                                    create_time=incomes[i].transfer.create_time;
                                }
                                incomes_list+='<tr><td>'+timestampToTime(incomes[i].created_at)+'</td><td>￥'+incomes[i].ongoing_shell+'</td><td>￥'+incomes[i].end_shell+'</td><td>￥'+incomes[i].refunding_shell+'</td><td>'+status+'</td><td>'+amount+'</td><td>'+payee+'</td><td>'+create_time+'</td>';
                            }
                            document.getElementById('translation_myincome_list').innerHTML=incomes_list;
                            if(incomes==''|| incomes ==null){
                                $('#kkpager').hide();
                            }
                            //生成分页
                            kkpager.generPageHtml({
                                pno: pageNo,
                                //总页码
                                total : a.pageTotal,
                                //总数据条数
                                totalRecords : a.total,
                                mode : 'click',
                                click : function(n){
                                    this.selectPage(pageNo);
                                    searchPage(n);
                                    return false;
                                }
                            },true);
                        }else{
                            layer.alert(a.msg)
                        }
                    }
                });
            }
            //init
            $(function () {
                searchFilter(1)
            });
            //ajax翻页
            function searchPage(n) {
                searchFilter(n);
            }
            $('.phone .delivery_list3 button').eq(1).on('click',function () {
                var p_this=$(this);
                var newphone =  p_this.parents('.delivery_bot').find('.delivery_list2').find('input').val();
                var oldphone = p_this.parents('.delivery_bot').find('.delivery_list').eq(0).find('p').text();
                if(!(/^1(3|4|5|7|8)\d{9}$/.test(newphone))){
                    layer.alert('请输入正确的手机号');
                    return false;
                }else if(newphone == oldphone){
                    layer.alert('手机号未做更改');
                    return false;
                }
                $.ajax({
                    url: api + '/api/index',
                    type:'post',
                    data:{
                        id:'1',
                        code:'123',
                        key:key,
                        method:'message.updateMobile',
                        module:'system',
                        mobile:newphone,
                        request_mode:'post',
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType:'json',
                    success:function(a){
                        if(a.status =='success') {
                            $('.phone').hide();
                            localStorage.setItem('umobile',newphone);
                            p_this.parents('.delivery_bot').find('.delivery_list').eq(0).find('p').text(newphone);
                            p_this.parents('.delivery_bot').find('.delivery_list2').find('input').val('');
                        }else{
                            layer.alert(a.msg)
                        }
                    }
                });
            });
            $('.password2 .delivery_list3 button').eq(1).on('click',function () {
                var ps_this=$(this);
                var password1 = ps_this.parents('.delivery_bot').find('.delivery_list2').eq(0).find('input').val();
                var password2 =  ps_this.parents('.delivery_bot').find('.delivery_list2').eq(1).find('input').val();
                if(password1 == ''){
                    layer.alert('请输入新密码');
                    return false;
                }else if(password1.length <6){
                    layer.alert('请输入6位以上密码');
                    return false;
                }else if(password2 == ''){
                    layer.alert('请输入确认密码');
                    return false;
                }else if(password1 != password2){
                    layer.alert('确认密码和新密码不一致');
                    return false;
                }
                $.ajax({
                    url: api + '/api/index',
                    type:'post',
                    data:{
                        key:key,
                        method:'user.edit_password',
                        module:'member',
                        password:password2,
                        request_mode:'post',
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType:'json',
                    success:function(a){
                        if(a.status =='success') {
                            $('.password2').hide();
                            window.location.href='index.html';
                        }else{
                            layer.alert(a.msg)
                        }
                    }
                });
            });
        });
    })
});