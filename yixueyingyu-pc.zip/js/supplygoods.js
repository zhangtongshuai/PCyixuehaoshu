requirejs(['common'],function(c){
    requirejs(['jquery','validata','template','style'],function ($,validata,template,style) {
        console.log(validata.isEqual(1,2));
        var api = validata.isApi();
        var uid = validata.isUid();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        var uname = localStorage.getItem('uname');
        var uavatar = localStorage.getItem('uavatar');
        var umobile = localStorage.getItem('umobile');
        validata.uinfo(uname,uavatar,umobile);
        layui.use(['form','layer'], function(){
            var form = layui.form
                ,layer = layui.layer;
            $(document).on('click','.order_record .supplygoods .classify_info .one-level .one-level_checked',function () {
                $(this).parents('.one-level').find('ul').show();
            });
            $(document).on('click','.order_record .supplygoods .classify_info .one-level ul li',function () {
               var onelevelid = $(this).attr('one_level_id');
               var onelevelname = $(this).text();
                $(this).parents('.one-level').find('.one-level_checked').attr('one_level_id',onelevelid);
                $(this).parents('.one-level').find('.one-level_checked b').text(onelevelname);
                $(this).parents('ul').find('li').removeClass('now_pitch_on');
                $(this).addClass('now_pitch_on');
                $('.classify_info .two-level .two-level_checked').attr('two_level_id','');
                $('.classify_info .two-level .two-level_checked').find('b').text('全部');
                $('.classify_info .three-level .three-level_checked').attr('three_level_id','');
                $('.classify_info .three-level .three-level_checked').find('b').text('全部');
                $(this).parents('ul').hide();
            });
            $(document).on('mouseleave','.order_record .supplygoods .classify_info .one-level',function () {
                $(this).find('ul').hide();
            });
            $(document).on('click','.order_record .supplygoods .classify_info .two-level .two-level_checked',function () {
                var one_level_id = $('.classify_info .one-level .one-level_checked').attr('one_level_id');
                $(this).parents('.two-level').find('ul').each(function () {
                   var oneid = $(this).attr('one_level_id');
                   if(oneid == one_level_id){
                    $(this).show();
                   }
                });
            });
            $(document).on('click','.order_record .supplygoods .classify_info .two-level ul li',function () {
               var twolevelid = $(this).attr('two_level_id');
               var twolevelname = $(this).text();
                $(this).parents('.two-level').find('.two-level_checked').attr('two_level_id',twolevelid);
                $(this).parents('.two-level').find('.two-level_checked b').text(twolevelname);
                $(this).parents('ul').find('li').removeClass('now_pitch_on');
                $(this).addClass('now_pitch_on');
                $('.classify_info .three-level .three-level_checked').attr('three_level_id','');
                $('.classify_info .three-level .three-level_checked').find('b').text('全部');
                $(this).parents('ul').hide();
            });
            $(document).on('mouseleave','.order_record .supplygoods .classify_info .two-level',function () {
                $(this).find('ul').hide();
            });
            $(document).on('click','.order_record .supplygoods .classify_info .three-level .three-level_checked',function () {
                var two_level_id = $('.classify_info .two-level .two-level_checked').attr('two_level_id');
                $(this).parents('.three-level').find('ul').each(function () {
                    var twoid = $(this).attr('two_level_id');
                    if(twoid == two_level_id){
                        $(this).show();
                    }
                });
            });
            $(document).on('click','.order_record .supplygoods .classify_info .three-level ul li',function () {
                var threelevelid = $(this).attr('three_level_id');
                var threelevelname = $(this).text();
                $(this).parents('.three-level').find('.three-level_checked').attr('three_level_id',threelevelid);
                $(this).parents('.three-level').find('.three-level_checked b').text(threelevelname);
                $(this).parents('ul').find('li').removeClass('now_pitch_on');
                $(this).addClass('now_pitch_on');
                $(this).parents('ul').hide();
            });
            $(document).on('mouseleave','.order_record .supplygoods .classify_info .three-level',function () {
                $(this).find('ul').hide();
            });
            function getUrlParam(key) {
                // 获取参数
                var url = window.location.search;
                // 正则筛选地址栏
                var reg = new RegExp("(^|&)" + key + "=([^&]*)(&|$)");
                // 匹配目标参数
                var result = url.substr(1).match(reg);
                //返回参数值
                return result ? decodeURIComponent(result[2]) : null;
            }
            var referee = window.btoa(uid); //字符串编码
            var refereeurl = 'http://m.yixuehaoshu.com/index.html?referee='+referee;
            $('.crumbs .active').text(refereeurl);
            $.ajax({
                type: 'get',
                url: api+'/api/index',
                data:{
                    key:key,
                    module:'market',
                    method:'category',
                    request_mode:'get',
                    sign:sign,
                    timestamp:timestamp
                },
                dataType: 'json',
                success: function (a) {
                    console.log(a);
                    if(a.status =='success') {
                        var obj = a.result;
                        var one_level = '';
                        var two_level_ul = '';
                        var three_level_ul = '';
                        for (var i in obj) {
                            one_level +='<li one_level_id ="'+obj[i].id+'">'+obj[i].name+'</li>';
                            var objs = obj[i].children;
                            var two_level = '<li two_level_id ="">全部</li>';
                            for(var j in objs){
                                two_level += '<li two_level_id ="'+objs[j].id+'">'+objs[j].name+'</li>';
                                var objss = objs[j].children;
                                var three_level = '<li three_level_id ="">全部</li>';
                                for(var k in objss){
                                    three_level += '<li three_level_id ="'+objss[k].id+'">'+objss[k].name+'</li>';
                                }
                                three_level_ul+='<ul two_level_id ="'+objs[j].id+'">'+three_level+'</ul>';
                            }
                            two_level_ul +='<ul one_level_id ="'+obj[i].id+'">'+two_level+'</ul>';
                        }
                        $('.classify_info .one-level ul').append(one_level);
                        $('.classify_info .two-level').append(two_level_ul);
                        $('.classify_info .three-level').append(three_level_ul);
                        var one_level_id = $('.classify_info .one-level ul li').eq(0).attr('one_level_id');
                        var one_level_name = $('.classify_info .one-level ul li').eq(0).text();
                        $('.classify_info .one-level ul li').eq(0).addClass('now_pitch_on');
                        $('.classify_info .two-level ul li').eq(0).addClass('now_pitch_on');
                        $('.classify_info .three-level ul li').eq(0).addClass('now_pitch_on');
                        $('.classify_info .one-level .one-level_checked').attr('one_level_id',one_level_id);
                        $('.classify_info .one-level .one-level_checked').find('b').text(one_level_name);
                        var c_id = $('.classify_info .one-level .one-level_checked').attr('one_level_id');
                        var one_leve = $('.classify_info .one-level .one-level_checked').find('b').text();
                        $('.goods_info h1 b').eq(1).hide();
                        $('.goods_info h1 b').eq(2).hide();
                        $('.goods_info h1 img').eq(1).hide();
                        $('.goods_info h1 img').eq(2).hide();
                        $('.goods_info h1 b').eq(0).html(one_leve);
                        goodslist(c_id);
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                }
            });
            $('.classify_info .filter_btn').on('click',function () {
                var one_id = $('.one-level').find('.one-level_checked').attr('one_level_id');
                var two_id = $('.two-level').find('.two-level_checked').attr('two_level_id');
                var three_id = $('.three-level').find('.three-level_checked').attr('three_level_id');
                var onel_evel = $('.one-level').find('.one-level_checked').find('b').text();
                var twol_evel = $('.two-level').find('.two-level_checked').find('b').text();
                var threel_evel = $('.three-level').find('.three-level_checked').find('b').text();
                if(one_id!=''&&two_id==''&&three_id==''){
                    $('.goods_info h1 b').eq(1).hide();
                    $('.goods_info h1 b').eq(2).hide();
                    $('.goods_info h1 img').eq(1).hide();
                    $('.goods_info h1 img').eq(2).hide();
                    $('.goods_info h1 b').eq(0).html(onel_evel);
                    goodslist(one_id);
                }else if(one_id!=''&&two_id!=''&&three_id==''){
                    $('.goods_info h1 b').eq(1).show();
                    $('.goods_info h1 b').eq(2).hide();
                    $('.goods_info h1 img').eq(1).show();
                    $('.goods_info h1 img').eq(2).hide();
                    $('.goods_info h1 b').eq(0).html(onel_evel);
                    $('.goods_info h1 b').eq(1).html(twol_evel);
                    goodslist(two_id);
                }else if(one_id!=''&&two_id!=''&&three_id!=''){
                    $('.goods_info h1 b').eq(1).show();
                    $('.goods_info h1 b').eq(2).show();
                    $('.goods_info h1 img').eq(1).show();
                    $('.goods_info h1 img').eq(2).show();
                    $('.goods_info h1 b').eq(0).html(onel_evel);
                    $('.goods_info h1 b').eq(1).html(twol_evel);
                    $('.goods_info h1 b').eq(2).html(threel_evel);
                    goodslist(three_id);
                }
            });
            //分页
            function goodslist(cid) {
                function searchFilter(pageindex){
                    var pageNo = getUrlParam('pageIndex');
                    if (!pageNo) {
                        pageNo = pageindex;
                    }
                    $.ajax({
                        url: api + '/api/index?page='+pageNo ,
                        type:'get',
                        data:{
                            key:key,
                            sign:sign,
                            timestamp:timestamp,
                            module:'market',
                            method:'category.show',
                            request_mode:'get',
                            category_id:cid,
                            order_by_field:'create_time',
                            sequence:'DESC'
                        },
                        headers:{
                            'X-Agent': 'reference'
                        },
                        dataType:'json',
                        success:function(a){
                            console.log(a);
                            if(a.status =='success') {
                                var goods = a.result;
                                if(goods==''|| goods ==null){
                                    $('#kkpager').hide();
                                }else{
                                    $('#kkpager').show();
                                }
                                var html1=template('tpl_translation_goods_list',goods);
                                document.getElementById('translation_goods_list').innerHTML=html1;
                                //生成分页
                                kkpager.generPageHtml({
                                    pno: pageNo,
                                    //总页码
                                    total : a.pageTotal,
                                    //总数据条数
                                    totalRecords : a.total,
                                    mode : 'click',
                                    click : function(n){
                                        this.selectPage(pageNo);
                                        searchPage(n);
                                        return false;
                                    }
                                },true);
                            }else{
                                layer.alert(a.msg);
                                $('#kkpager').hide();
                            }
                        }
                    });
                }
                //init
                $(function () {
                    searchFilter(1)
                });
                //ajax翻页
                function searchPage(n) {
                    searchFilter(n);
                }
            }
            $('.phone .delivery_list3 button').eq(1).on('click',function () {
                var p_this=$(this);
                var newphone =  p_this.parents('.delivery_bot').find('.delivery_list2').find('input').val();
                var oldphone = p_this.parents('.delivery_bot').find('.delivery_list').eq(0).find('p').text();
                if(!(/^1(3|4|5|7|8)\d{9}$/.test(newphone))){
                    layer.alert('请输入正确的手机号');
                    return false;
                }else if(newphone == oldphone){
                    layer.alert('手机号未做更改');
                    return false;
                }
                $.ajax({
                    url: api + '/api/index',
                    type:'post',
                    data:{
                        id:'1',
                        code:'123',
                        key:key,
                        method:'message.updateMobile',
                        module:'system',
                        mobile:newphone,
                        request_mode:'post',
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType:'json',
                    success:function(a){
                        if(a.status =='success') {
                            $('.phone').hide();
                            localStorage.setItem('umobile',newphone);
                            p_this.parents('.delivery_bot').find('.delivery_list').eq(0).find('p').text(newphone);
                            p_this.parents('.delivery_bot').find('.delivery_list2').find('input').val('');
                        }else{
                            layer.alert(a.msg)
                        }
                    }
                });
            });
            $('.password2 .delivery_list3 button').eq(1).on('click',function () {
                var ps_this=$(this);
                var password1 = ps_this.parents('.delivery_bot').find('.delivery_list2').eq(0).find('input').val();
                var password2 =  ps_this.parents('.delivery_bot').find('.delivery_list2').eq(1).find('input').val();
                if(password1 == ''){
                    layer.alert('请输入新密码');
                    return false;
                }else if(password1.length <6){
                    layer.alert('请输入6位以上密码');
                    return false;
                }else if(password2 == ''){
                    layer.alert('请输入确认密码');
                    return false;
                }else if(password1 != password2){
                    layer.alert('确认密码和新密码不一致');
                    return false;
                }
                $.ajax({
                    url: api + '/api/index',
                    type:'post',
                    data:{
                        key:key,
                        method:'user.edit_password',
                        module:'member',
                        password:password2,
                        request_mode:'post',
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType:'json',
                    success:function(a){
                        if(a.status =='success') {
                            $('.password2').hide();
                            window.location.href='index.html';
                        }else{
                            layer.alert(a.msg)
                        }
                    }
                });
            });
        });
    })
});