requirejs(['common'],function(c){
    requirejs(['jquery','validata','style'],function ($,validata,style) {
        console.log(validata.isEqual(1,2))
        var api = validata.isApi();
        var uid = validata.isUid();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        var uname = localStorage.getItem('uname');
        var uavatar = localStorage.getItem('uavatar');
        var umobile = localStorage.getItem('umobile');
        var role = localStorage.getItem('role');
        validata.uinfo(uname,uavatar,umobile);
        var oid= validata.getQueryString('oid');
        function returnFloat(value){
            var value=Math.round(parseFloat(value)*100)/100;
            var xsd=value.toString().split(".");
            if(xsd.length==1){
                value=value.toString()+".00";
                return value;
            }
            if(xsd.length>1){
                if(xsd[1].length<2){
                    value=value.toString()+"0";
                }
                return value;
            }
        }
        function phonem(telVal) {
            var newTelVal = '';
            if(telVal.length > 0){
                for(var i = 0; i < telVal.length; i++){
                    if(i < 3 || i >= telVal.length-4){
                        newTelVal += telVal[i];
                    }else{
                        newTelVal += '*';
                    }
                }
                return newTelVal;
            }
        }
        layui.use(['form','laydate','layer','element'], function(){
            var form = layui.form
                ,layer = layui.layer;
            $.ajax({
                url: api + '/api/index',
                type:'post',
                data:{
                    key:key,
                    sign:sign,
                    timestamp:timestamp,
                    method:'order.detail',
                    module:'order',
                    order_id:oid,
                    request_mode:'post',
                    uid:uid,
                    user_type:role
                },
                dataType:'json',
                success:function(a){
                    if(a.status =='success') {
                        var orderdetails = a.result;
                        var curTime = new Date().getTime();
                        if(orderdetails.status == 2){
                            $('.order_details .order_details_list').eq(0).find('.state_list').eq(0).find('h3').text(orderdetails.created_at);
                            $('.order_details .order_details_list').eq(0).find('.state_list').eq(1).find('h3').text(orderdetails.pay_time);
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(0).find('font').text('待发货');
                            if(orderdetails.referee_info!=null){
                                $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(1).find('font').text(orderdetails.referee_info.name);
                                $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(1).find('b').text(orderdetails.referee_info.mobile);
                            }
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(2).find('i').text(orderdetails.consignee);
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(2).find('b').text(phonem(orderdetails.mobile));
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(2).find('em').text(orderdetails.province+orderdetails.city+orderdetails.district+orderdetails.address);
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(3).find('font').text(orderdetails.remark);
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_right .order_delivery').find('p').text('买家已付款，等待店铺发货');
                            $('.order_details .order_details_list .state_list div.state3').css('background-position','50% -170px');
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_right .order_delivery').find('span').eq(0).text('待发货');
                        }else if(orderdetails.status == 3){
                            $('.order_details .order_details_list').eq(0).find('.state_list').eq(0).find('h3').text(orderdetails.created_at);
                            $('.order_details .order_details_list').eq(0).find('.state_list').eq(1).find('h3').text(orderdetails.pay_time);
                            $('.order_details .order_details_list').eq(0).find('.state_list').eq(2).find('h3').text(orderdetails.deliver_time);
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(0).find('font').text('已发货');
                            if(orderdetails.referee_info!=null){
                                $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(1).find('font').text(orderdetails.referee_info.name);
                                $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(1).find('b').text(orderdetails.referee_info.mobile);
                            }
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(2).find('i').text(orderdetails.consignee);
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(2).find('b').text(phonem(orderdetails.mobile));
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(2).find('em').text(orderdetails.province+orderdetails.city+orderdetails.district+orderdetails.address);
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(3).find('font').text(orderdetails.remark);
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_right .order_delivery').find('p').text('已发货，等待确认收货');
                            $('.order_details .order_details_list .state_list div.state3').css('background-position','50% -170px');
                            $('.order_details .order_details_list .state_list div.state5').css('background-position','50% -170px');
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_right .order_delivery').find('span').eq(0).text('已发货');
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_right .order_delivery').find('span').eq(2).html('快递单号：'+orderdetails.express_no+'<a class="modify_expressno_btn" style="margin-left: 20px;text-decoration: underline;color: #f70;cursor: pointer;">修改</a>');
                            var express_company = orderdetails.express_company;
                            var express_no = orderdetails.express_no;
                            var order_no = orderdetails.order_no;
                            $.ajax({
                                url: api + '/api/index',
                                type: 'get',
                                data: {
                                    express_company:express_company,
                                    express_no:express_no,
                                    key: key,
                                    sign: sign,
                                    timestamp: timestamp,
                                    method: 'order.'+order_no+'.logistics',
                                    module: 'order',
                                    request_mode: 'get'
                                },
                                dataType: 'json',
                                success: function (b) {
                                    if(b.State){
                                        if(b.State ==3){
                                            $('.order_details .express_info').show();
                                            var express_info= '';
                                            var num = b.Traces.length;
                                            for(var j=0;j<b.Traces.length;j++){
                                                if(j==(num-1)){
                                                    express_info+='<li><span>'+b.Traces[j].AcceptTime+'</span><font><b style="width: 24px;height: 24px;color: #fff;background: #ddd;">发</b></font><em>'+b.Traces[j].AcceptStation+'</em></li>';
                                                }else{
                                                    express_info+='<li><span>'+b.Traces[j].AcceptTime+'</span><font><b></b></font><em>'+b.Traces[j].AcceptStation+'</em></li>';
                                                }
                                            }
                                            var addressinfo1 = $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(2).find('em').text();
                                            var collect_goods = '<li><span></span><font><b style="width: 24px;height: 24px;color: #fff;background: #ddd;">收</b></font><em>[收货地址]'+addressinfo1+'</em></li>';
                                            $('.order_details .express_info ul').append(collect_goods);
                                            $('.order_details .express_info ul').append(express_info);
                                            $('.express_info ul li').eq(1).find('b').css('background','#f70');
                                        }
                                    }
                                }
                            });
                            var deliver_data = new Date(orderdetails.deliver_time);
                            var deliver_time = deliver_data.getTime();
                            var expire_time = deliver_time + 15*24*60*60*1000;
                            var overplus_time = Math.floor((expire_time - curTime)/1000);
                            var take_over_time = '';
                            if(overplus_time<0){
                                take_over_time = "已超时";
                            }else{
                                setInterval(function(){
                                    var curTime1 = new Date().getTime();
                                    var remaining_time1 = Math.floor((expire_time-curTime1)/1000);
                                    timeStamp(remaining_time1);
                                },1000);
                                function timeStamp(second_time){
                                    if(parseInt(second_time) > 60){
                                        var second = parseInt(second_time) % 60;
                                        var min = parseInt(second_time / 60);
                                        min = min < 10 ? '0' + min : min;
                                        second = second < 10 ? '0' + second : second;
                                        take_over_time = "00 天 "+"00 时 "+min + " 分 " + second + " 秒 ";
                                        $('.order_details .order_details_list').eq(1).find('.state_infor .infor_right .order_delivery').find('span').eq(1).text('确认收货时间还剩：'+take_over_time);
                                        if( min > 60 ){
                                            min = parseInt(second_time / 60) % 60;
                                            min = min < 10 ? '0' + min : min;
                                            var hour = parseInt( parseInt(second_time / 60) /60 );
                                            hour = hour < 10 ? '0' + hour : hour;
                                            take_over_time = "00 天 "+ hour + " 小时 " + min + " 分 " + second + " 秒 ";
                                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_right .order_delivery').find('span').eq(1).text('确认收货时间还剩：'+take_over_time);
                                            if( hour > 24 ){
                                                hour = parseInt( parseInt(second_time / 60) /60 ) % 24;
                                                var day = parseInt( parseInt( parseInt(second_time / 60) /60 ) / 24 );
                                                day = day < 10 ? '0' + day : day;
                                                hour = hour < 10 ? '0' + hour : hour;
                                                take_over_time = day + " 天 " + hour + " 小时 " + min + " 分 " + second + " 秒 ";
                                                $('.order_details .order_details_list').eq(1).find('.state_infor .infor_right .order_delivery').find('span').eq(1).text('确认收货时间还剩：'+take_over_time);
                                            }
                                        }
                                    }else if(0<=parseInt(second_time) <60){
                                        var second = parseInt(second_time);
                                        second = second < 10 ? '0' + second : second;
                                        take_over_time = "00 天 "+"00 时 "+"00 分 "+ second + " 秒 ";
                                        $('.order_details .order_details_list').eq(1).find('.state_infor .infor_right .order_delivery').find('span').eq(1).text('确认收货时间还剩：'+take_over_time);
                                    }else{
                                        take_over_time = "已超时";
                                        $('.order_details .order_details_list').eq(1).find('.state_infor .infor_right .order_delivery').find('span').eq(1).text('确认收货时间还剩：'+take_over_time);
                                    }
                                }
                            }
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_right .order_delivery').find('span').eq(1).text('确认收货时间还剩：'+take_over_time);
                        }else if(orderdetails.status == 4){
                            $('.order_details .order_details_list').eq(0).find('.state_list').eq(0).find('h3').text(orderdetails.created_at);
                            $('.order_details .order_details_list').eq(0).find('.state_list').eq(1).find('h3').text(orderdetails.pay_time);
                            $('.order_details .order_details_list').eq(0).find('.state_list').eq(2).find('h3').text(orderdetails.deliver_time);
                            $('.order_details .order_details_list').eq(0).find('.state_list').eq(3).find('h3').text(orderdetails.confirm_time);
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(0).find('font').text('交易完成');
                            if(orderdetails.referee_info!=null){
                                $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(1).find('font').text(orderdetails.referee_info.name);
                                $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(1).find('b').text(orderdetails.referee_info.mobile);
                            }
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(2).find('i').text(orderdetails.consignee);
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(2).find('b').text(phonem(orderdetails.mobile));
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(2).find('em').text(orderdetails.province+orderdetails.city+orderdetails.district+orderdetails.address);
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(3).find('font').text(orderdetails.remark);
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_right .order_delivery').find('p').text('交易完成');
                            $('.order_details .order_details_list .state_list div.state3').css('background-position','50% -170px');
                            $('.order_details .order_details_list .state_list div.state5').css('background-position','50% -170px');
                            $('.order_details .order_details_list .state_list div.state7').css('background-position','50% -68px');
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_right .order_delivery').find('span').eq(0).text('订单已完成');
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_right .order_delivery').find('span').eq(1).text('');
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_right .order_delivery').find('span').eq(2).text('快递单号：'+orderdetails.express_no);
                        }else if(orderdetails.status == 5){
                            $('.order_details .order_details_list').eq(0).find('.state_list').eq(0).find('h3').text(orderdetails.created_at);
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(0).find('font').text('已取消（退款中）');
                            if(orderdetails.referee_info!=null){
                                $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(1).find('font').text(orderdetails.referee_info.name);
                                $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(1).find('b').text(orderdetails.referee_info.mobile);
                            }
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(2).find('i').text(orderdetails.consignee);
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(2).find('b').text(phonem(orderdetails.mobile));
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(2).find('em').text(orderdetails.province+orderdetails.city+orderdetails.district+orderdetails.address);
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(3).find('font').text(orderdetails.remark);
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_right .order_delivery').find('p').text('订单已取消（退款中）');
                            $('.order_details .order_details_list .state_list div.state3').css('background-position','50% -170px');
                            $('.order_details .order_details_list .state_list div.state5').css('background-position','50% -238px');
                            $('.order_details .order_details_list .state_list div.state7').css('background-position','50% -272px');
                        }else if(orderdetails.status == 6){
                            $('.order_details .order_details_list').eq(0).find('.state_list').eq(0).find('h3').text(orderdetails.created_at);
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(0).find('font').text('已取消（退款成功）');
                            if(orderdetails.referee_info!=null){
                                $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(1).find('font').text(orderdetails.referee_info.name);
                                $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(1).find('b').text(orderdetails.referee_info.mobile);
                            }
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(2).find('i').text(orderdetails.consignee);
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(2).find('b').text(phonem(orderdetails.mobile));
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(2).find('em').text(orderdetails.province+orderdetails.city+orderdetails.district+orderdetails.address);
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_left div').eq(3).find('font').text(orderdetails.remark);
                            $('.order_details .order_details_list').eq(1).find('.state_infor .infor_right .order_delivery').find('p').text('订单已取消（退款成功）');
                            $('.order_details .order_details_list .state_list div.state3').css('background-position','50% -170px');
                            $('.order_details .order_details_list .state_list div.state5').css('background-position','50% -238px');
                            $('.order_details .order_details_list .state_list div.state7').css('background-position','50% -272px');
                        }
                        var orderinfos = '';
                        for(var i=0;i<orderdetails.ordergoods.length;i++){
                            var prices = orderdetails.ordergoods[i].price*orderdetails.ordergoods[i].number;
                            prices = returnFloat(prices);
                            var commision = orderdetails.ordergoods[i].referee_percentage*orderdetails.ordergoods[i].number;
                            commision = returnFloat(commision);
                            orderinfos +='<tr><td><img src="'+orderdetails.ordergoods[i].image+'"><span>'+orderdetails.ordergoods[i].market_name+'</span></td><td>￥'+orderdetails.ordergoods[i].price+'</td><td>￥'+orderdetails.ordergoods[i].referee_percentage+'</td><td>×'+orderdetails.ordergoods[i].number+'</td><td>￥<b>'+commision+'</b></td></tr>';
                        }
                        $('.order_details .order_details_list').eq(2).find('tbody').append(orderinfos);
                        var Total_tip = 0.00;
                        $('.order_details_list table tbody').find('tr').each(function () {
                            var tip = $(this).find('td').eq(4).find('b').html();
                            Total_tip += tip*100
                        });
                        Total_tip = returnFloat(Total_tip/100);
                        $('.order_details .order_details_list .total_sales span').eq(0).find('b').eq(1).text(Total_tip);
                    }else{
                        layer.alert(a.msg)
                    }
                }
            });
            $('.phone .delivery_list3 button').eq(1).on('click',function () {
                var p_this=$(this);
                var newphone =  p_this.parents('.delivery_bot').find('.delivery_list2').find('input').val();
                var oldphone = p_this.parents('.delivery_bot').find('.delivery_list').eq(0).find('p').text();
                if(!(/^1(3|4|5|7|8)\d{9}$/.test(newphone))){
                    layer.alert('请输入正确的手机号');
                    return false;
                }else if(newphone == oldphone){
                    layer.alert('手机号未做更改');
                    return false;
                }
                $.ajax({
                    url: api + '/api/index',
                    type:'post',
                    data:{
                        id:'1',
                        code:'123',
                        key:key,
                        method:'message.updateMobile',
                        module:'system',
                        mobile:newphone,
                        request_mode:'post',
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType:'json',
                    success:function(a){
                        if(a.status =='success') {
                            $('.phone').hide();
                            localStorage.setItem('umobile',newphone);
                            p_this.parents('.delivery_bot').find('.delivery_list').eq(0).find('p').text(newphone);
                            p_this.parents('.delivery_bot').find('.delivery_list2').find('input').val('');
                        }else{
                            layer.alert(a.msg)
                        }
                    }
                });
            });
            $('.password2 .delivery_list3 button').eq(1).on('click',function () {
                var ps_this=$(this);
                var password1 = ps_this.parents('.delivery_bot').find('.delivery_list2').eq(0).find('input').val();
                var password2 =  ps_this.parents('.delivery_bot').find('.delivery_list2').eq(1).find('input').val();
                if(password1 == ''){
                    layer.alert('请输入新密码');
                    return false;
                }else if(password1.length <6){
                    layer.alert('请输入6位以上密码');
                    return false;
                }else if(password2 == ''){
                    layer.alert('请输入确认密码');
                    return false;
                }else if(password1 != password2){
                    layer.alert('确认密码和新密码不一致');
                    return false;
                }
                $.ajax({
                    url: api + '/api/index',
                    type:'post',
                    data:{
                        key:key,
                        method:'user.edit_password',
                        module:'member',
                        password:password2,
                        request_mode:'post',
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType:'json',
                    success:function(a){
                        if(a.status =='success') {
                            $('.password2').hide();
                            window.location.href='index.html';
                        }else{
                            layer.alert(a.msg)
                        }
                    }
                });
            });
        });
    })
});