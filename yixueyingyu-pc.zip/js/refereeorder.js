requirejs(['common'],function(c){
    requirejs(['jquery','validata','template','style'],function ($,validata,template,style) {
        console.log(validata.isEqual(1,2))
        var api = validata.isApi();
        var uid = validata.isUid();
        var key = validata.signCont().key;
        var sign = validata.signCont().sign;
        var timestamp = validata.signCont().timestamp;
        var uname = localStorage.getItem('uname');
        var uavatar = localStorage.getItem('uavatar');
        var umobile = localStorage.getItem('umobile');
        var role = localStorage.getItem('role');
        var orderstatus = '2,3,4,5,6';
        validata.uinfo(uname,uavatar,umobile);
        layui.use(['form','laydate','layer','element'], function(){
            var form = layui.form
                ,layer = layui.layer
                ,laydate = layui.laydate
                ,element = layui.element
            //执行一个laydate实例
            laydate.render({
                elem: '#start_time'
            });
            laydate.render({
                elem: '#end_time'
            });

            function o_data(orderstatus) {
                return orderdata = {
                    module:'order',
                    method:'order.get_all',
                    request_mode:'get',
                    status:orderstatus,
                    key:key,
                    sign:sign,
                    timestamp:timestamp,
                    uid:uid,
                    user_type:role
                }
            }
            orderlist(o_data(orderstatus));
            $('.order_record .order_list .layui-tab-title li').eq(0).on('click',function () {
                orderstatus='2,3,4,5,6';
                $(".order_search_type").find("select").siblings("div.layui-form-select").find("dd:first").click();
                $(".order_search_status").find("select").siblings("div.layui-form-select").find("dd:first").click();
                $('.order_search_info').val('');
                $('#start_time').val('');
                $('#end_time').val('');
                $('#kkpager').show();
                $('#translation_order_list').html('');
                orderlist(o_data(orderstatus));
            });
            $('.order_record .order_list .layui-tab-title li').eq(1).on('click',function () {
                orderstatus=2;
                $(".order_search_type").find("select").siblings("div.layui-form-select").find("dd:first").click();
                $(".order_search_status").find("select").siblings("div.layui-form-select").find("dd:first").click();
                $('.order_search_info').val('');
                $('#start_time').val('');
                $('#end_time').val('');
                $('#kkpager').show();
                $('#translation_order_list').html('');
                orderlist(o_data(orderstatus));
            });
            $('.order_record .order_list .layui-tab-title li').eq(2).on('click',function () {
                orderstatus=3;
                $(".order_search_type").find("select").siblings("div.layui-form-select").find("dd:first").click();
                $(".order_search_status").find("select").siblings("div.layui-form-select").find("dd:first").click();
                $('.order_search_info').val('');
                $('#start_time').val('');
                $('#end_time').val('');
                $('#kkpager').show();
                $('#translation_order_list').html('');
                orderlist(o_data(orderstatus));
            });
            $('.order_record .order_list .layui-tab-title li').eq(3).on('click',function () {
                orderstatus=4;
                $(".order_search_type").find("select").siblings("div.layui-form-select").find("dd:first").click();
                $(".order_search_status").find("select").siblings("div.layui-form-select").find("dd:first").click();
                $('.order_search_info').val('');
                $('#start_time').val('');
                $('#end_time').val('');
                $('#kkpager').show();
                $('#translation_order_list').html('');
                orderlist(o_data(orderstatus));
            });
            $('.order_record .order_list .layui-tab-title li').eq(4).on('click',function () {
                orderstatus='5,6';
                $(".order_search_type").find("select").siblings("div.layui-form-select").find("dd:first").click();
                $(".order_search_status").find("select").siblings("div.layui-form-select").find("dd:first").click();
                $('.order_search_info').val('');
                $('#start_time').val('');
                $('#end_time').val('');
                $('#kkpager').show();
                $('#translation_order_list').html('');
                orderlist(o_data(orderstatus));
            });
            $('.inquiry_btn').on('click',function () {
                var first_value= $('.order_search_info').val();
                var status = $('.order_search_status select option:checked').attr('value');
                var time1 = $('#start_time').val();
                var time2 = $('#end_time').val();
                var atype = $('.order_search_type select option:checked').attr('value');
                if(status == '2,3,4,5,6'){
                    $('.order_list .layui-tab-title li').removeClass('layui-this');
                    $('.order_list .layui-tab-title li').eq(0).addClass('layui-this');
                }else if(status ==2){
                    $('.order_list .layui-tab-title li').removeClass('layui-this');
                    $('.order_list .layui-tab-title li').eq(1).addClass('layui-this');
                }else if(status ==3){
                    $('.order_list .layui-tab-title li').removeClass('layui-this');
                    $('.order_list .layui-tab-title li').eq(2).addClass('layui-this');
                }else if(status ==4){
                    $('.order_list .layui-tab-title li').removeClass('layui-this');
                    $('.order_list .layui-tab-title li').eq(3).addClass('layui-this');
                }else if(status =='5,6'){
                    $('.order_list .layui-tab-title li').removeClass('layui-this');
                    $('.order_list .layui-tab-title li').eq(4).addClass('layui-this');
                }
                var norderdata ={
                    first_value:first_value,
                    module:'order',
                    method:'order.search',
                    request_mode:'get',
                    status:status,
                    key:key,
                    sign:sign,
                    timestamp:timestamp,
                    time1:time1,
                    time2:time2,
                    type:atype,
                    uid:uid,
                    user_type:role
                };
                $('#translation_order_list').html('');
                orderlist(norderdata);

            });
            function getUrlParam(key) {
                // 获取参数
                var url = window.location.search;
                // 正则筛选地址栏
                var reg = new RegExp("(^|&)" + key + "=([^&]*)(&|$)");
                // 匹配目标参数
                var result = url.substr(1).match(reg);
                //返回参数值
                return result ? decodeURIComponent(result[2]) : null;
            }
            //分页
            function timestampToTime(timestamp) {
                var date = new Date(timestamp);//时间戳为10位需*1000，时间戳为13位的话不需乘1000
                var Y = date.getFullYear() + '-';
                var M = (date.getMonth()+1 < 10 ? '0'+(date.getMonth()+1) : date.getMonth()+1) + '-';
                var D = (date.getDate()<10?'0'+date.getDate():date.getDate()) + ' ';
                var h = (date.getHours()<10?'0'+date.getHours():date.getHours()) + ':';
                var m = date.getMinutes()<10?'0'+date.getMinutes():date.getMinutes();
                return Y+M+D+h+m;
            }
            function orderlist(orderdata) {
                function searchFilter(pageindex){
                    var pageNo = getUrlParam('pageIndex');
                    if (!pageNo) {
                        pageNo = pageindex;
                    }
                    $.ajax({
                        url: api + '/api/index?page='+pageNo ,
                        type:'get',
                        data:orderdata,
                        dataType:'json',
                        success:function(a){
                            console.log(a);
                            if(a.status =='success') {
                                var orders = a.result;
                                for(var i=0;i<orders.length;i++){
                                    var t = orders[i].created_at;
                                    t = Date.parse(t.replace(/-/g,"/"));
                                    var T = new Date(t);
                                    var ct = T.getTime();
                                    orders[i].created_at=timestampToTime(ct);
                                }
                                var html1=template('tpl_translation_order_list',orders);
                                document.getElementById('translation_order_list').innerHTML=html1;
                                if(orders==''|| orders ==null){
                                    $('#kkpager').hide();
                                }
                                //生成分页
                                kkpager.generPageHtml({
                                    pno: pageNo,
                                    //总页码
                                    total : a.pageTotal,
                                    //总数据条数
                                    totalRecords : a.total,
                                    mode : 'click',
                                    click : function(n){
                                        this.selectPage(pageNo);
                                        searchPage(n);
                                        return false;
                                    }
                                },true);
                            }else{
                                layer.alert(a.msg)
                                $('#kkpager').hide();
                            }
                        }
                    });
                }
                //init
                $(function () {
                    searchFilter(1)
                });
                //ajax翻页
                function searchPage(n) {
                    searchFilter(n);
                }
            }
            $('.phone .delivery_list3 button').eq(1).on('click',function () {
                var p_this=$(this);
                var newphone =  p_this.parents('.delivery_bot').find('.delivery_list2').find('input').val();
                var oldphone = p_this.parents('.delivery_bot').find('.delivery_list').eq(0).find('p').text();
                if(!(/^1(3|4|5|7|8)\d{9}$/.test(newphone))){
                    layer.alert('请输入正确的手机号');
                    return false;
                }else if(newphone == oldphone){
                    layer.alert('手机号未做更改');
                    return false;
                }
                $.ajax({
                    url: api + '/api/index',
                    type:'post',
                    data:{
                        id:'1',
                        code:'123',
                        key:key,
                        method:'message.updateMobile',
                        module:'system',
                        mobile:newphone,
                        request_mode:'post',
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType:'json',
                    success:function(a){
                        if(a.status =='success') {
                            $('.phone').hide();
                            localStorage.setItem('umobile',newphone);
                            p_this.parents('.delivery_bot').find('.delivery_list').eq(0).find('p').text(newphone);
                            p_this.parents('.delivery_bot').find('.delivery_list2').find('input').val('');
                        }else{
                            layer.alert(a.msg)
                        }
                    }
                });
            });
            $('.password2 .delivery_list3 button').eq(1).on('click',function () {
                var ps_this=$(this);
                var password1 = ps_this.parents('.delivery_bot').find('.delivery_list2').eq(0).find('input').val();
                var password2 =  ps_this.parents('.delivery_bot').find('.delivery_list2').eq(1).find('input').val();
                if(password1 == ''){
                    layer.alert('请输入新密码');
                    return false;
                }else if(password1.length <6){
                    layer.alert('请输入6位以上密码');
                    return false;
                }else if(password2 == ''){
                    layer.alert('请输入确认密码');
                    return false;
                }else if(password1 != password2){
                    layer.alert('确认密码和新密码不一致');
                    return false;
                }
                $.ajax({
                    url: api + '/api/index',
                    type:'post',
                    data:{
                        key:key,
                        method:'user.edit_password',
                        module:'member',
                        password:password2,
                        request_mode:'post',
                        sign:sign,
                        timestamp:timestamp,
                        uid:uid
                    },
                    dataType:'json',
                    success:function(a){
                        if(a.status =='success') {
                            $('.password2').hide();
                            window.location.href='index.html';
                        }else{
                            layer.alert(a.msg)
                        }
                    }
                });
            });
        });
    })
});